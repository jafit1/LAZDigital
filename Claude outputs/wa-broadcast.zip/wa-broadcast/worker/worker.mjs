#!/usr/bin/env node
/**
 * worker/worker.mjs
 * Dispatcher yang jalan terus — untuk komputer sendiri atau VPS, sebagai
 * pengganti Vercel Cron. Pengiriman mulai seketika setelah kampanye dibuat,
 * tidak menunggu menit berikutnya.
 *
 * Jalankan:  npm run worker
 * Hentikan:  Ctrl+C (putaran yang sedang jalan diselesaikan dulu)
 *
 * DUA CARA KERJA — dipilih otomatis dari STORE_DRIVER:
 *
 *  1. STORE_DRIVER=upstash  -> mode LANGSUNG.
 *     Worker membaca antrean di Redis sendiri. Boleh dijalankan berbarengan
 *     dengan web app, bahkan di mesin lain; kunci dispatcher menjaga agar
 *     tidak ada pesan terkirim dua kali.
 *
 *  2. STORE_DRIVER=memory   -> mode TITIP.
 *     Penyimpanan mode lokal hidup di dalam memori satu proses, jadi worker
 *     TIDAK boleh mengutak-atik datanya sendiri (dua proses = dua salinan
 *     data yang saling menimpa). Worker cukup menitipkan pekerjaan ke web app
 *     lewat POST /api/cron/dispatch, dan web app yang mengirim.
 *     Butuh CRON_SECRET dan web app (npm run dev) sedang hidup.
 */

import { muatEnv } from '../lib/muat-env.js'
muatEnv()

const { cfg, periksaKonfigurasi } = await import('../lib/env.js')
const { tidur } = await import('../lib/util.js')

const c = cfg()
const MODE = (process.env.WORKER_MODE || (c.store.driver === 'memory' ? 'titip' : 'langsung')).toLowerCase()
const APP_URL = (process.env.APP_URL || 'http://127.0.0.1:3000').replace(/\/+$/, '')

let berhenti = false
process.on('SIGINT', () => {
  if (berhenti) process.exit(1)
  berhenti = true
  console.log('\n[worker] menyelesaikan putaran terakhir, tekan Ctrl+C sekali lagi untuk keluar paksa…')
})
process.on('SIGTERM', () => {
  berhenti = true
})

const log = (pesan) => console.log(`[${new Date().toLocaleTimeString('id-ID', { hour12: false })}] ${pesan}`)

console.log('='.repeat(66))
console.log(' WA BROADCAST — worker pengiriman')
console.log('='.repeat(66))
log(`Penyimpanan  : ${c.store.driver}`)
log(`Cara kerja   : ${MODE === 'titip' ? `titip ke web app (${APP_URL})` : 'langsung baca antrean Redis'}`)
log(`Graph API    : ${c.wa.graphBaseUrl}/${c.wa.graphVersion}`)
log(`Laju kirim   : ${c.rate.mps} pesan/detik, paralel ${c.rate.concurrency}`)
log(`Jeda 1 nomor : ${c.rate.sameNumberCooldown} detik · coba maksimal ${c.rate.maxAttempts}x`)
if (c.dryRun) log('MODE UJI (WA_DRY_RUN=true): pesan TIDAK benar-benar dikirim ke Meta')
const konfig = periksaKonfigurasi()
for (const w of konfig.wajib) log(`WAJIB DIISI  : ${w}`)
if (MODE === 'titip' && !c.cronSecret) log('WAJIB DIISI  : CRON_SECRET (dipakai untuk menitip pekerjaan ke web app)')
console.log('-'.repeat(66))

/* ------------------------------------------------------------------ *
 * Mode TITIP — memanggil endpoint cron di web app
 * ------------------------------------------------------------------ */
async function putaranTitip() {
  const res = await fetch(`${APP_URL}/api/cron/dispatch?detik=8`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${c.cronSecret}` },
  })
  if (res.status === 401) throw new Error('web app menolak: CRON_SECRET tidak cocok')
  if (!res.ok) throw new Error(`web app membalas HTTP ${res.status}`)
  return res.json()
}

/* ------------------------------------------------------------------ *
 * Mode LANGSUNG — dispatcher di dalam proses ini
 * ------------------------------------------------------------------ */
let jalankanDispatcher = null
if (MODE === 'langsung') {
  ;({ jalankanDispatcher } = await import('../lib/dispatcher.js'))
}

async function putaranLangsung() {
  return jalankanDispatcher({ budgetMs: 8000, log, berhenti: () => berhenti })
}

/* ------------------------------------------------------------------ *
 * Putaran utama
 * ------------------------------------------------------------------ */
let sepi = 0

while (!berhenti) {
  let hasil
  try {
    hasil = MODE === 'titip' ? await putaranTitip() : await putaranLangsung()
  } catch (e) {
    log(`gagal: ${e.message}`)
    await tidur(5000)
    continue
  }

  if (hasil.dilewati) {
    log(`dilewati: ${hasil.alasan}`)
    await tidur(2000)
    continue
  }

  const h = hasil.hitungan || {}
  const bekerja = (h.terkirim || 0) + (h.gagal || 0) + (h.ditunda || 0) > 0

  if (bekerja) {
    sepi = 0
    log(
      `terkirim=${h.terkirim || 0} gagal=${h.gagal || 0} ditunda=${h.ditunda || 0} ` +
        `dilewati=${h.dilewati || 0} | antrean siap=${hasil.antrean?.siap ?? '?'} tunda=${hasil.antrean?.tunda ?? '?'}`
    )
  } else {
    sepi++
    if (sepi === 1 || sepi % 30 === 0) {
      const tunda = hasil.antrean?.tunda ?? 0
      log(
        tunda > 0
          ? `menunggu jeda ${tunda} pekerjaan tertunda (jeda nomor / percobaan ulang)…`
          : 'antrean kosong — menunggu kampanye baru…'
      )
    }
    await tidur(2000)
  }
}

log('worker berhenti.')
process.exit(0)
