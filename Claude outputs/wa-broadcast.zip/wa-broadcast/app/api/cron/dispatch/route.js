/**
 * Pemicu dispatcher untuk MODE SERVERLESS.
 *
 * GET|POST /api/cron/dispatch
 *
 * Diizinkan bila salah satu terpenuhi:
 *   - header "Authorization: Bearer <CRON_SECRET>"  (dipakai Vercel Cron)
 *   - permintaan datang dari admin yang sudah masuk (tombol "Kirim sekarang")
 *
 * Vercel Cron paling cepat 1 menit sekali. Satu invokasi bekerja selama
 * WA_DISPATCH_BUDGET_SECONDS lalu berhenti dengan sopan; sisa antrean
 * dilanjutkan invokasi berikutnya. Kunci dispatcher mencegah dua invokasi
 * yang bertumpuk mengirim pesan yang sama dua kali.
 */

import { jsonOk, jsonError, bungkus } from '../../../../lib/http.js'
import { cfg } from '../../../../lib/env.js'
import { sesiSekarang } from '../../../../lib/auth.js'
import { jalankanDispatcher } from '../../../../lib/dispatcher.js'
import { samaAman } from '../../../../lib/util.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'
export const maxDuration = 60 // detik — sesuaikan dengan paket Vercel Anda

async function tangani(req) {
  const c = cfg()
  const header = req.headers.get('authorization') || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : ''

  const lewatCron = !!c.cronSecret && samaAman(token, c.cronSecret)
  const lewatAdmin = !lewatCron && !!(await sesiSekarang(req))

  if (!lewatCron && !lewatAdmin) return jsonError('Tidak berwenang.', 401)

  const url = new URL(req.url)
  const budgetDetik = Math.min(Number(url.searchParams.get('detik') || c.rate.budgetSeconds), 55)
  const batasPekerjaan = Number(url.searchParams.get('batas') || 0) || undefined

  const mulai = Date.now()
  const hasil = await jalankanDispatcher({
    budgetMs: budgetDetik * 1000,
    batasPekerjaan,
    log: (p) => console.log('[dispatch]', p),
  })

  /* --- Rantai otomatis ---
     Dengan jeda 10–20 detik per pesan, satu putaran hanya menghabiskan
     sebagian antrean. Di Vercel paket Hobby cron hanya boleh sekali sehari,
     jadi putaran ini memanggil dirinya sendiri sekali lagi selama antrean
     masih ada. Tiga pengaman: kunci dispatcher (tidak ada dua putaran
     berjalan bersamaan), penghitung rantai, dan hanya dijalankan bila
     putaran ini benar-benar mengerjakan sesuatu. */
  const rantai = Number(url.searchParams.get('rantai') || 0)
  let rantaiBerikut = false
  const adaSisa = (hasil.antrean?.total ?? 0) > 0
  const adaKemajuan = (hasil.hitungan?.terkirim || 0) + (hasil.hitungan?.gagal || 0) > 0

  if (!hasil.dilewati && adaSisa && adaKemajuan && rantai < c.rate.maxRantai && c.cronSecret) {
    const lanjut = new URL(url.toString())
    lanjut.searchParams.set('rantai', String(rantai + 1))
    /* Tidak ditunggu: fungsi ini harus segera membalas. Kegagalan panggilan
       ini bukan masalah — cron harian tetap membersihkan sisanya. */
    fetch(lanjut.toString(), {
      method: 'POST',
      headers: { Authorization: `Bearer ${c.cronSecret}` },
    }).catch(() => {})
    rantaiBerikut = true
  }

  return jsonOk({
    ...hasil,
    lamaMs: Date.now() - mulai,
    pemicu: lewatCron ? 'cron' : 'admin',
    rantai,
    rantaiBerikut,
  })
}

export const GET = bungkus(tangani)
export const POST = bungkus(tangani)
