/**
 * GET /api/templates          -> daftar template APPROVED dari WABA (dengan cache 5 menit)
 * GET /api/templates?segar=1  -> paksa tarik ulang dari Meta
 */

import { jsonOk, jsonError, wajibAdmin } from '../../../lib/http.js'
import { getJson, setJson, k } from '../../../lib/store/index.js'
import { pengirim, namaPengirim, pakaiPesanBebas } from '../../../lib/pengirim/index.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

const UMUR_CACHE_MS = 5 * 60 * 1000

export const GET = wajibAdmin(async (req) => {
  const url = new URL(req.url)
  const segar = url.searchParams.get('segar') === '1'

  /* Fonnte tidak punya template yang disetujui Meta — isi pesan ditulis
     sendiri lewat composer. Balas kosong dengan keterangan, bukan galat. */
  if (pakaiPesanBebas()) {
    return jsonOk({
      pengirim: namaPengirim(),
      pakaiPesanBebas: true,
      template: [],
      nomor: null,
      dariCache: false,
      keterangan: 'Pengirim Fonnte memakai pesan teks bebas. Susun isinya di tab "Pesan".',
    })
  }

  if (!segar) {
    const cache = await getJson(k.cacheTemplate())
    if (cache && Date.now() - cache.pada < UMUR_CACHE_MS) {
      return jsonOk({ template: cache.template, nomor: cache.nomor, dariCache: true, pada: cache.pada })
    }
  }

  let template
  try {
    template = await pengirim().daftarTemplate()
  } catch (e) {
    // Kalau gagal, kembalikan cache lama (kalau ada) supaya dashboard tetap terpakai.
    const cache = await getJson(k.cacheTemplate())
    if (cache) {
      return jsonOk({
        template: cache.template,
        nomor: cache.nomor,
        dariCache: true,
        pada: cache.pada,
        peringatan: `Gagal menarik dari Meta: ${e.message}`,
      })
    }
    return jsonError(`Gagal menarik template dari Meta: ${e.message}`, 502)
  }

  let nomor = null
  try {
    nomor = (await pengirim().infoPengirim()).mentah
  } catch {
    /* bukan hal fatal */
  }

  const isi = { pada: Date.now(), template, nomor }
  await setJson(k.cacheTemplate(), isi)
  return jsonOk({ template, nomor, dariCache: false, pada: isi.pada })
})
