import { jsonOk, wajibAdmin } from '../../../../lib/http.js'
import { ambilLogWebhook } from '../../../../lib/webhook.js'
import { ukuranAntrean } from '../../../../lib/queue.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = wajibAdmin(async (req) => {
  const url = new URL(req.url)
  const jumlah = Math.min(Number(url.searchParams.get('jumlah') || 30), 200)
  return jsonOk({ log: await ambilLogWebhook(jumlah), antrean: await ukuranAntrean() })
})
