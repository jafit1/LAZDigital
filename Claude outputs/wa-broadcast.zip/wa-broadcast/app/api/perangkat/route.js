/**
 * GET /api/perangkat
 *
 * Keadaan pengirim yang sedang aktif:
 *  - Fonnte : nomor, status sambungan, sisa kuota, masa aktif paket
 *  - Meta   : nomor, nama terverifikasi, mutu, tier batas pesan
 *
 * Dashboard memanggil ini sebelum kampanye dijalankan supaya kegagalan yang
 * sebenarnya soal kuota habis atau perangkat terputus terlihat lebih awal.
 */

import { jsonOk, jsonError, wajibAdmin } from '../../../lib/http.js'
import { pengirim, namaPengirim, jalurWebhook } from '../../../lib/pengirim/index.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = wajibAdmin(async () => {
  try {
    const info = await pengirim().infoPengirim()
    const peringatan = []
    if (info.tersambung === false) {
      peringatan.push('Perangkat WhatsApp terputus — scan ulang QR di dashboard Fonnte sebelum mengirim.')
    }
    if (typeof info.kuota === 'number' && info.kuota <= 0) {
      peringatan.push('Kuota Fonnte habis. Pengiriman akan gagal sampai paket diisi ulang.')
    } else if (typeof info.kuota === 'number' && info.kuota < 100) {
      peringatan.push(`Sisa kuota Fonnte tinggal ${info.kuota} pesan.`)
    }
    return jsonOk({ pengirim: namaPengirim(), jalurWebhook: jalurWebhook(), info, peringatan })
  } catch (e) {
    return jsonError(`Tidak bisa membaca keadaan pengirim: ${e.message}`, 502, {
      pengirim: namaPengirim(),
      jalurWebhook: jalurWebhook(),
    })
  }
})
