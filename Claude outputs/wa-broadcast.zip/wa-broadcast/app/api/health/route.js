import { jsonOk, bungkus } from '../../../lib/http.js'
import { periksaKonfigurasi, cfg } from '../../../lib/env.js'
import { store } from '../../../lib/store/index.js'
import { ukuranAntrean } from '../../../lib/queue.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = bungkus(async () => {
  const c = cfg()
  const konfig = periksaKonfigurasi()

  let penyimpanan = 'gagal'
  try {
    await store().ping()
    penyimpanan = 'baik'
  } catch (e) {
    penyimpanan = `gagal: ${e.message}`
  }

  let antrean = null
  try {
    antrean = await ukuranAntrean()
  } catch {
    /* biarkan null bila penyimpanan bermasalah */
  }

  return jsonOk({
    waktu: new Date().toISOString(),
    penyimpanan: { driver: c.store.driver, keadaan: penyimpanan },
    pengirim: c.pengirim,
    fonnte: c.pengirim === 'fonnte' ? { basis: c.fonnte.baseUrl, tokenTerisi: !!c.fonnte.token } : null,
    graph: { versi: c.wa.graphVersion, basis: c.wa.graphBaseUrl },
    laju: c.rate,
    dryRun: c.dryRun,
    antrean,
    konfig,
  })
})
