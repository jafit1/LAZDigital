/**
 * GET    /api/pesan/{id}  -> satu pesan tersimpan
 * DELETE /api/pesan/{id}  -> hapus dari pustaka
 */

import { jsonOk, jsonError, wajibAdmin } from '../../../../lib/http.js'
import { ambilPesan, hapusPesan, ambilPlaceholder } from '../../../../lib/pesan.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = wajibAdmin(async (req, ctx) => {
  const { id } = await ctx.params
  const pesan = await ambilPesan(id)
  if (!pesan) return jsonError('Pesan tidak ditemukan.', 404)
  return jsonOk({ pesan, placeholder: ambilPlaceholder(pesan.teks) })
})

export const DELETE = wajibAdmin(async (req, ctx) => {
  const { id } = await ctx.params
  const pesan = await ambilPesan(id)
  if (!pesan) return jsonError('Pesan tidak ditemukan.', 404)
  await hapusPesan(id)
  return jsonOk({ dihapus: id })
})
