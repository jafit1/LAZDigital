/**
 * Pustaka pesan tersimpan (mode Fonnte).
 *
 * GET  /api/pesan                 -> daftar pesan tersimpan
 * POST /api/pesan                 -> simpan pesan baru / perbarui (kirim "id")
 * POST /api/pesan?aksi=periksa    -> periksa pesan tanpa menyimpan
 *      { teks, kolom: ["nama","kota"] } -> galat, peringatan, daftar placeholder
 */

import { jsonOk, jsonError, wajibAdmin, bacaJsonBody } from '../../../lib/http.js'
import { daftarPesan, simpanPesan, periksaPesan, ambilPlaceholder } from '../../../lib/pesan.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = wajibAdmin(async () => {
  const pesan = await daftarPesan({ limit: 100 })
  return jsonOk({ pesan })
})

export const POST = wajibAdmin(async (req) => {
  const url = new URL(req.url)
  const body = await bacaJsonBody(req)

  if (url.searchParams.get('aksi') === 'periksa') {
    const hasil = periksaPesan(body.teks, { kolomTersedia: body.kolom || [] })
    return jsonOk({ ...hasil })
  }

  if (!String(body.teks || '').trim()) return jsonError('Isi pesan masih kosong.')

  const cek = periksaPesan(body.teks, { kolomTersedia: body.kolom || [] })
  if (!cek.sah) return jsonError(cek.galat.join(' '), 400, { galat: cek.galat })

  const baris = await simpanPesan({
    id: body.id,
    nama: body.nama,
    teks: body.teks,
    lampiranUrl: body.lampiranUrl,
    lampiranNama: body.lampiranNama,
  })

  return jsonOk({ pesan: baris, placeholder: ambilPlaceholder(baris.teks), peringatan: cek.peringatan })
})
