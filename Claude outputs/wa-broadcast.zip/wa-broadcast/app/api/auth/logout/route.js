import { jsonOk, bungkus } from '../../../../lib/http.js'
import { logout } from '../../../../lib/auth.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const POST = bungkus(async (req) => {
  const cookie = await logout(req)
  return jsonOk({}, { headers: { 'Set-Cookie': cookie } })
})
