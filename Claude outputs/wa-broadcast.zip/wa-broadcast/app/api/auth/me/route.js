import { jsonOk, bungkus } from '../../../../lib/http.js'
import { sesiSekarang } from '../../../../lib/auth.js'
import { periksaKonfigurasi, cfg } from '../../../../lib/env.js'
import { namaPengirim, pakaiPesanBebas, jalurWebhook } from '../../../../lib/pengirim/index.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = bungkus(async (req) => {
  const sesi = await sesiSekarang(req)
  const c = cfg()
  return jsonOk({
    masuk: !!sesi,
    username: sesi?.username || null,
    // Tidak ada kredensial di sini — hanya keterangan setelan yang aman ditampilkan.
    setelan: {
      driver: c.store.driver,
      pengirim: namaPengirim(),
      pakaiPesanBebas: pakaiPesanBebas(),
      jalurWebhook: jalurWebhook(),
      graphVersi: c.wa.graphVersion,
      mps: c.rate.mps,
      jedaMin: c.rate.jedaMin,
      jedaMax: c.rate.jedaMax,
      jedaNomorDetik: c.rate.sameNumberCooldown,
      maxCoba: c.rate.maxAttempts,
      dryRun: c.dryRun,
    },
    konfig: sesi ? periksaKonfigurasi() : null,
  })
})
