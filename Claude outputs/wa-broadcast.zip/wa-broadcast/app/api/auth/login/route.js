import { jsonOk, jsonError, bungkus, bacaJsonBody } from '../../../../lib/http.js'
import { login } from '../../../../lib/auth.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const POST = bungkus(async (req) => {
  const { username, sandi } = await bacaJsonBody(req)
  const hasil = await login(req, username, sandi)
  if (!hasil.ok) return jsonError(hasil.pesan, hasil.status)
  return jsonOk({ username }, { headers: { 'Set-Cookie': hasil.cookie } })
})
