/**
 * POST /api/contacts/parse
 *
 * Dua cara memberi data:
 *   1. multipart/form-data  -> field "berkas" (CSV / TSV / XLSX)
 *   2. application/json     -> { teks: "62812...;Nama;Kode\n..." }
 *
 * Balasan berisi pratinjau baris, nama kolom, dan daftar baris yang ditolak
 * beserta alasannya — supaya admin bisa memperbaiki datanya sebelum mengirim.
 */

import { jsonOk, jsonError, wajibAdmin } from '../../../../lib/http.js'
import { bacaDelimited, bacaExcel, petakanKontak, headerParameter, saringOptout } from '../../../../lib/kontak.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

const BATAS_BARIS = 50_000

export const POST = wajibAdmin(async (req) => {
  const tipe = req.headers.get('content-type') || ''
  let matriks = []
  let sumber = ''

  if (tipe.includes('multipart/form-data')) {
    const form = await req.formData()
    const berkas = form.get('berkas')
    if (!berkas || typeof berkas === 'string') return jsonError('Berkas tidak ditemukan di field "berkas".')
    const nama = String(berkas.name || '').toLowerCase()
    const buf = Buffer.from(await berkas.arrayBuffer())
    sumber = berkas.name

    if (nama.endsWith('.xlsx') || nama.endsWith('.xls') || nama.endsWith('.xlsm')) {
      try {
        matriks = await bacaExcel(buf)
      } catch (e) {
        return jsonError(e.message, 400)
      }
    } else {
      matriks = bacaDelimited(buf.toString('utf8'))
    }
  } else {
    const body = await req.json().catch(() => ({}))
    if (!body.teks || !String(body.teks).trim()) return jsonError('Tempelkan dulu datanya di kolom teks.')
    sumber = 'tempelan teks'
    matriks = bacaDelimited(String(body.teks))
  }

  if (matriks.length === 0) return jsonError('Data terbaca kosong.')
  if (matriks.length > BATAS_BARIS) {
    return jsonError(`Terlalu banyak baris (${matriks.length}). Batas satu unggahan ${BATAS_BARIS} baris.`)
  }

  const url = new URL(req.url)
  const kolomTeleponParam = url.searchParams.get('kolomTelepon')
  const hasil = petakanKontak(matriks, {
    kolomTelepon: kolomTeleponParam !== null ? Number(kolomTeleponParam) : undefined,
    kodeNegara: url.searchParams.get('kodeNegara') || '62',
  })

  const { tertolak: kenaOptout } = await saringOptout(hasil.baris.map((b) => b.telepon))

  return jsonOk({
    sumber,
    header: hasil.header,
    adaHeader: hasil.adaHeader,
    kolomTelepon: hasil.kolomTelepon,
    headerParameter: headerParameter(hasil.header, hasil.kolomTelepon),
    jumlahSah: hasil.baris.length,
    jumlahDitolak: hasil.ditolak.length,
    jumlahOptout: kenaOptout.length,
    optout: kenaOptout.slice(0, 50),
    // Kirim seluruh baris sah supaya dashboard bisa langsung memakainya saat
    // membuat kampanye (tanpa mengunggah dua kali).
    baris: hasil.baris,
    ditolak: hasil.ditolak.slice(0, 200),
  })
})
