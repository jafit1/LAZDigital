/**
 * Daftar tolak kirim (opt-out).
 *
 * GET    /api/optout                          -> daftar nomor
 * POST   /api/optout   { "nomor": ["08.."] }  -> tambah
 * DELETE /api/optout   { "nomor": ["08.."] }  -> hapus
 *
 * Nomor di daftar ini otomatis dilewati saat kampanye dibuat, dan otomatis
 * bertambah saat penerima membalas "STOP" / "BERHENTI" (lihat lib/webhook.js).
 */

import { jsonOk, jsonError, wajibAdmin, bacaJsonBody } from '../../../lib/http.js'
import { daftarOptout, tambahOptout, hapusOptout } from '../../../lib/kontak.js'
import { normalisasiTelepon } from '../../../lib/util.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

function normalkan(daftar) {
  const ok = []
  const gagal = []
  for (const n of daftar || []) {
    const h = normalisasiTelepon(n)
    if (h.ok) ok.push(h.telepon)
    else gagal.push({ isi: String(n), alasan: h.alasan })
  }
  return { ok, gagal }
}

export const GET = wajibAdmin(async () => {
  const nomor = await daftarOptout()
  return jsonOk({ jumlah: nomor.length, nomor: nomor.sort() })
})

export const POST = wajibAdmin(async (req) => {
  const { nomor } = await bacaJsonBody(req)
  if (!Array.isArray(nomor) || nomor.length === 0) return jsonError('Kirim field "nomor" berupa array.')
  const { ok, gagal } = normalkan(nomor)
  const ditambah = await tambahOptout(ok)
  return jsonOk({ ditambah, gagal })
})

export const DELETE = wajibAdmin(async (req) => {
  const { nomor } = await bacaJsonBody(req)
  if (!Array.isArray(nomor) || nomor.length === 0) return jsonError('Kirim field "nomor" berupa array.')
  const { ok, gagal } = normalkan(nomor)
  const dihapus = await hapusOptout(ok)
  return jsonOk({ dihapus, gagal })
})
