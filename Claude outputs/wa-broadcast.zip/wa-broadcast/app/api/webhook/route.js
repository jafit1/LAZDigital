/**
 * Webhook Meta.
 *
 * GET  /api/webhook  -> handshake verifikasi (hub.mode, hub.verify_token, hub.challenge)
 * POST /api/webhook  -> kejadian status pesan & pesan masuk
 *
 * Aturan penting:
 *  - Badan permintaan dibaca MENTAH (req.text()) karena tanda tangan HMAC
 *    dihitung atas byte aslinya. JSON.parse dilakukan setelah tanda tangan sah.
 *  - Balas 200 secepat mungkin. Meta mengulang pengiriman bila kita lambat
 *    atau membalas kode galat, dan pengulangan itu bisa menumpuk.
 */

import { jsonOk, bungkus } from '../../../lib/http.js'
import { verifikasiHandshake, verifikasiTandaTangan, prosesWebhook, catatLogWebhook } from '../../../lib/webhook.js'
import { cfg } from '../../../lib/env.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = bungkus(async (req) => {
  const url = new URL(req.url)
  const hasil = verifikasiHandshake(url.searchParams)
  if (!hasil.sah) {
    console.warn('[webhook] handshake ditolak:', hasil.alasan)
    return new Response('Forbidden', { status: 403 })
  }
  // Meta mengharapkan hub.challenge dibalas sebagai teks polos.
  return new Response(hasil.challenge, { status: 200, headers: { 'Content-Type': 'text/plain' } })
})

export const POST = bungkus(async (req) => {
  const mentah = await req.text()
  const tandaTangan = req.headers.get('x-hub-signature-256')

  const cek = verifikasiTandaTangan(mentah, tandaTangan)
  if (!cek.sah) {
    // Di mode lokal tanpa App Secret, izinkan agar mock server bisa dipakai.
    const bolehLewat = cfg().store.driver === 'memory' && !cfg().wa.appSecret
    if (!bolehLewat) {
      console.warn('[webhook] tanda tangan ditolak:', cek.alasan)
      return new Response('Invalid signature', { status: 401 })
    }
    console.warn('[webhook] MODE LOKAL: tanda tangan dilewati —', cek.alasan)
  }

  let payload
  try {
    payload = JSON.parse(mentah)
  } catch {
    return new Response('Bad JSON', { status: 400 })
  }

  if (payload.object !== 'whatsapp_business_account') {
    return jsonOk({ diabaikan: true })
  }

  const ringkasan = await prosesWebhook(payload)
  await catatLogWebhook(payload, { ringkasan: { ...ringkasan, kampanye: undefined } })

  return jsonOk({ ringkasan })
})
