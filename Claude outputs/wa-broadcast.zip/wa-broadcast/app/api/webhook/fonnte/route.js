/**
 * Webhook Fonnte.
 *
 * POST /api/webhook/fonnte?kunci=<FONNTE_WEBHOOK_SECRET>
 *
 * Pasang URL ini di dashboard Fonnte pada dua tempat:
 *   - Webhook Update Message Status  (status pesan: terkirim/diterima/dibaca/gagal)
 *   - Webhook Reply Message          (menangkap balasan "STOP")
 *
 * Fonnte tidak menandatangani permintaannya, jadi rahasianya ada di query
 * string. GET disediakan hanya untuk memastikan URL-nya benar dari browser.
 */

import { jsonOk, jsonError, bungkus } from '../../../../lib/http.js'
import { verifikasiKunci, prosesWebhookFonnte } from '../../../../lib/webhook-fonnte.js'
import { catatLogWebhook } from '../../../../lib/webhook.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = bungkus(async (req) => {
  const url = new URL(req.url)
  const cek = verifikasiKunci(url.searchParams)
  if (!cek.sah) return jsonError(`Kunci webhook tidak sah: ${cek.alasan}`, 401)
  return jsonOk({ pesan: 'Webhook Fonnte siap menerima. Pasang URL ini (beserta ?kunci=) di dashboard Fonnte.' })
})

export const POST = bungkus(async (req) => {
  const url = new URL(req.url)
  const cek = verifikasiKunci(url.searchParams)
  if (!cek.sah) {
    console.warn('[webhook-fonnte] ditolak:', cek.alasan)
    return jsonError('Kunci webhook tidak sah.', 401)
  }

  /* Fonnte mengirim JSON, tetapi beberapa setelan lamanya memakai
     form-urlencoded. Keduanya diterima. */
  const tipe = req.headers.get('content-type') || ''
  let payload = {}
  const mentah = await req.text()
  try {
    if (tipe.includes('application/x-www-form-urlencoded')) {
      payload = Object.fromEntries(new URLSearchParams(mentah))
    } else {
      payload = mentah ? JSON.parse(mentah) : {}
    }
  } catch {
    return jsonError('Badan permintaan tidak bisa dibaca.', 400)
  }

  const ringkasan = await prosesWebhookFonnte(payload)
  await catatLogWebhook(payload, { sumber: 'fonnte', ringkasan: { ...ringkasan, kampanye: undefined } })

  return jsonOk({ ringkasan })
})
