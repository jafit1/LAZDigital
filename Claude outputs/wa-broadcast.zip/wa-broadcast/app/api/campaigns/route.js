/**
 * GET  /api/campaigns        -> daftar kampanye terbaru + ringkasan status
 * POST /api/campaigns        -> buat kampanye baru dan langsung masukkan ke antrean
 *
 * Badan POST:
 * {
 *   "nama": "Broadcast Ramadan",
 *   "template": { "nama":"promo_ramadan", "bahasa":"id", "kategori":"MARKETING",
 *                 "bernama":false, "variabel":["1","2"], "teksBody":"..." },
 *   "pemetaan": [0, 2],                  // variabel ke-n diisi kolom parameter ke-?
 *   "pemetaanBernama": { "nama":0 },     // dipakai bila template memakai {{nama}}
 *   "headerTetap": { "tipe":"image", "nilai":"https://..." },
 *   "pemetaanHeader": { "tipe":"text", "kolom":1 },
 *   "pemetaanTombol": [ { "index":0, "subType":"url", "kolom":2 } ],
 *   "baris": [ { "telepon":"628...", "params":["Ma'ruf","VC-01"] } ],
 *   "langsungJalan": true
 * }
 */

import { jsonOk, jsonError, wajibAdmin, bacaJsonBody } from '../../../lib/http.js'
import { buatKampanye, daftarKampanye } from '../../../lib/kampanye.js'
import { bersihkanNilaiParam } from '../../../lib/whatsapp.js'
import { namaPengirim, pakaiPesanBebas } from '../../../lib/pengirim/index.js'
import { periksaPesan, ambilPesan, catatPemakaian, isiPlaceholder } from '../../../lib/pesan.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = wajibAdmin(async (req) => {
  const url = new URL(req.url)
  const limit = Math.min(Number(url.searchParams.get('limit') || 30), 100)
  const offset = Math.max(Number(url.searchParams.get('offset') || 0), 0)
  const kampanye = await daftarKampanye({ limit, offset })
  return jsonOk({ kampanye })
})

export const POST = wajibAdmin(async (req, ctx) => {
  const body = await bacaJsonBody(req)

  /* Mode ditentukan pengirim yang aktif, bukan oleh badan permintaan:
     Fonnte selalu pesan bebas, Meta selalu template. */
  const mode = body.mode || (pakaiPesanBebas() ? 'pesan' : 'template')

  if (mode === 'pesan') return buatKampanyePesan(req, ctx, body)
  return buatKampanyeTemplate(req, ctx, body)
})

/* ================================================================== *
 * MODE PESAN (Fonnte) — teks bebas berplaceholder
 * ================================================================== */

async function buatKampanyePesan(req, ctx, body) {
  if (!Array.isArray(body.baris) || body.baris.length === 0) return jsonError('Daftar penerima kosong.')
  if (body.baris.length > 50_000) return jsonError('Maksimal 50.000 penerima per kampanye.')

  /* Isi pesan boleh diambil dari pustaka (pesanId) atau ditulis langsung. */
  let teks = String(body.pesan?.teks || '')
  let lampiranUrl = body.pesan?.lampiranUrl || null
  let lampiranNama = body.pesan?.lampiranNama || null
  const pesanId = body.pesan?.pesanId || null

  if (pesanId) {
    const tersimpan = await ambilPesan(pesanId)
    if (!tersimpan) return jsonError('Pesan tersimpan tidak ditemukan.', 404)
    if (!teks.trim()) teks = tersimpan.teks
    lampiranUrl = lampiranUrl ?? tersimpan.lampiranUrl
    lampiranNama = lampiranNama ?? tersimpan.lampiranNama
  }

  const kolomTersedia = Array.isArray(body.kolom) ? body.kolom : []
  const cek = periksaPesan(teks, { kolomTersedia })
  if (!cek.sah) return jsonError(cek.galat.join(' '), 400, { galat: cek.galat })

  /* Susun penerima. Setiap baris membawa nilai per NAMA kolom, bukan urutan,
     supaya placeholder bisa dipindah-pindah di isi pesan tanpa memetakan ulang. */
  const penerima = []
  const galatBaris = []

  body.baris.forEach((b, i) => {
    const telepon = String(b.telepon || '').replace(/\D/g, '')
    if (!telepon) {
      galatBaris.push({ baris: i + 1, alasan: 'nomor kosong' })
      return
    }
    const nilaiKolom = {}
    if (b.kolom && typeof b.kolom === 'object') {
      for (const [nama, nilai] of Object.entries(b.kolom)) nilaiKolom[nama] = String(nilai ?? '')
    } else if (Array.isArray(b.params)) {
      kolomTersedia.forEach((nama, idx) => {
        nilaiKolom[nama] = String(b.params[idx] ?? '')
      })
    }
    penerima.push({ telepon, nama: nilaiKolom.nama || b.nama || null, kolom: nilaiKolom })
  })

  if (penerima.length === 0) return jsonError('Tidak ada penerima yang sah.', 400, { galatBaris })

  const hasil = await buatKampanye({
    nama: body.nama,
    mode: 'pesan',
    pengirim: namaPengirim(),
    pesan: { teks, lampiranUrl, lampiranNama, pesanId },
    penerima,
    dibuatOleh: ctx.sesi.username,
    langsungJalan: body.langsungJalan !== false,
  })

  if (pesanId) await catatPemakaian(pesanId)

  return jsonOk({
    kampanye: hasil.kampanye,
    jumlahAntre: hasil.jumlahAntre,
    jumlahDilewati: hasil.jumlahDilewati,
    galatBaris,
    peringatan: cek.peringatan,
    /* Pratinjau pesan pertama yang sudah terisi — bukti isian placeholder benar. */
    contohPesan: penerima.slice(0, 3).map((p) => ({
      telepon: p.telepon,
      teks: isiPlaceholder(teks, { ...p.kolom, telepon: p.telepon }),
    })),
    catatan:
      hasil.kampanye.status === 'berjalan'
        ? 'Kampanye masuk antrean. Pastikan worker berjalan (npm run worker) atau tekan "Jalankan dispatcher sekarang".'
        : 'Kampanye dibuat dalam keadaan ditahan. Tekan "Lanjutkan" untuk mulai mengirim.',
  })
}

/* ================================================================== *
 * MODE TEMPLATE (Meta Cloud API resmi)
 * ================================================================== */

async function buatKampanyeTemplate(req, ctx, body) {
  // ---------- validasi ----------
  if (!body.template?.nama) return jsonError('Template belum dipilih.')
  if (!body.template?.bahasa) return jsonError('Kode bahasa template belum diisi.')
  if (!Array.isArray(body.baris) || body.baris.length === 0) return jsonError('Daftar penerima kosong.')
  if (body.baris.length > 50_000) return jsonError('Maksimal 50.000 penerima per kampanye.')

  const variabel = Array.isArray(body.template.variabel) ? body.template.variabel : []
  const bernama = !!body.template.bernama

  if (bernama) {
    const petaB = body.pemetaanBernama || {}
    const belum = variabel.filter((v) => petaB[v] === undefined || petaB[v] === null || petaB[v] === '')
    if (belum.length) return jsonError(`Variabel belum dipetakan ke kolom: ${belum.join(', ')}`)
  } else if (variabel.length > 0) {
    const peta = Array.isArray(body.pemetaan) ? body.pemetaan : []
    if (peta.length !== variabel.length) {
      return jsonError(
        `Template ini butuh ${variabel.length} parameter, tetapi pemetaan kolom yang dikirim ${peta.length}.`
      )
    }
    if (peta.some((x) => !Number.isInteger(Number(x)) || Number(x) < 0)) {
      return jsonError('Pemetaan kolom harus berupa indeks angka.')
    }
  }

  // ---------- susun penerima ----------
  const penerima = []
  const galatBaris = []

  body.baris.forEach((b, i) => {
    const telepon = String(b.telepon || '').replace(/\D/g, '')
    if (!telepon) {
      galatBaris.push({ baris: i + 1, alasan: 'nomor kosong' })
      return
    }
    const kolom = Array.isArray(b.params) ? b.params : []

    const baris = { telepon, nama: b.nama || null, params: [], bernama: null, header: null, tombol: [] }

    if (bernama) {
      baris.bernama = {}
      for (const v of variabel) {
        baris.bernama[v] = bersihkanNilaiParam(kolom[Number(body.pemetaanBernama[v])] ?? '')
      }
    } else if (variabel.length > 0) {
      baris.params = body.pemetaan.map((idx) => bersihkanNilaiParam(kolom[Number(idx)] ?? ''))
    }

    if (body.pemetaanHeader && body.pemetaanHeader.kolom !== undefined) {
      const nilai = String(kolom[Number(body.pemetaanHeader.kolom)] ?? '').trim()
      if (nilai) baris.header = { tipe: body.pemetaanHeader.tipe || 'text', nilai }
    }

    for (const t of body.pemetaanTombol || []) {
      const nilai = String(kolom[Number(t.kolom)] ?? '').trim()
      if (nilai) baris.tombol.push({ index: Number(t.index) || 0, subType: t.subType || 'url', nilai })
    }

    penerima.push(baris)
  })

  if (penerima.length === 0) return jsonError('Tidak ada penerima yang sah.', 400, { galatBaris })

  const hasil = await buatKampanye({
    nama: body.nama,
    mode: 'template',
    pengirim: namaPengirim(),
    template: {
      nama: body.template.nama,
      bahasa: body.template.bahasa,
      kategori: body.template.kategori,
      bernama,
      variabel,
      teksBody: body.template.teksBody,
    },
    headerTetap: body.headerTetap || null,
    penerima,
    dibuatOleh: ctx.sesi.username,
    langsungJalan: body.langsungJalan !== false,
  })

  return jsonOk({
    kampanye: hasil.kampanye,
    jumlahAntre: hasil.jumlahAntre,
    jumlahDilewati: hasil.jumlahDilewati,
    galatBaris,
    catatan:
      hasil.kampanye.status === 'berjalan'
        ? 'Kampanye masuk antrean. Pastikan worker berjalan (npm run worker) atau cron /api/cron/dispatch aktif.'
        : 'Kampanye dibuat dalam keadaan ditahan. Tekan "Lanjutkan" untuk mulai mengirim.',
  })
}
