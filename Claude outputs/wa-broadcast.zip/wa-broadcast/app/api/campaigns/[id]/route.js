import { jsonOk, jsonError, wajibAdmin } from '../../../../lib/http.js'
import { ambilKampanye, ambilStat } from '../../../../lib/kampanye.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const GET = wajibAdmin(async (req, ctx) => {
  // Next 15+ menyerahkan params sebagai Promise; await aman untuk kedua versi.
  const { id } = await ctx.params
  const kampanye = await ambilKampanye(id)
  if (!kampanye) return jsonError('Kampanye tidak ditemukan.', 404)
  const stat = await ambilStat(id)
  return jsonOk({ kampanye, stat })
})
