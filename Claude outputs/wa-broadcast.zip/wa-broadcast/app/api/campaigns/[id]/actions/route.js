/**
 * POST /api/campaigns/{id}/actions
 * Badan: { "aksi": "tahan" | "lanjutkan" | "batalkan" | "ulangi-gagal" }
 */

import { jsonOk, jsonError, wajibAdmin, bacaJsonBody } from '../../../../../lib/http.js'
import {
  tahanKampanye,
  lanjutkanKampanye,
  batalkanKampanye,
  ulangiYangGagal,
  ambilKampanye,
  ambilStat,
} from '../../../../../lib/kampanye.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export const POST = wajibAdmin(async (req, ctx) => {
  const { id } = await ctx.params
  const { aksi } = await bacaJsonBody(req)

  const ada = await ambilKampanye(id)
  if (!ada) return jsonError('Kampanye tidak ditemukan.', 404)

  let hasil
  switch (aksi) {
    case 'tahan':
      hasil = await tahanKampanye(id, 'Ditahan manual oleh admin')
      break
    case 'lanjutkan':
      hasil = await lanjutkanKampanye(id)
      break
    case 'batalkan':
      hasil = await batalkanKampanye(id)
      break
    case 'ulangi-gagal':
      hasil = await ulangiYangGagal(id)
      break
    default:
      return jsonError('Aksi tidak dikenal. Pilihan: tahan, lanjutkan, batalkan, ulangi-gagal.')
  }

  return jsonOk({ hasil, kampanye: await ambilKampanye(id), stat: await ambilStat(id) })
})
