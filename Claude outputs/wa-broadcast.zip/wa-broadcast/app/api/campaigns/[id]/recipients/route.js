/**
 * GET /api/campaigns/{id}/recipients?status=gagal&limit=100&offset=0
 * GET /api/campaigns/{id}/recipients?format=csv   -> unduh laporan lengkap
 */

import { jsonOk, jsonError, wajibAdmin } from '../../../../../lib/http.js'
import { ambilKampanye, daftarPenerima } from '../../../../../lib/kampanye.js'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

function kolomCsv(nilai) {
  const s = String(nilai ?? '')
  return /[";\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

function waktuLokal(ms) {
  return ms ? new Date(ms).toISOString() : ''
}

export const GET = wajibAdmin(async (req, ctx) => {
  const { id } = await ctx.params
  const url = new URL(req.url)
  const kampanye = await ambilKampanye(id)
  if (!kampanye) return jsonError('Kampanye tidak ditemukan.', 404)

  const status = url.searchParams.get('status') || null
  const format = url.searchParams.get('format')

  if (format === 'csv') {
    const semua = await daftarPenerima(id, { status, limit: 100_000, offset: 0 })
    const kepala = [
      'telepon', 'status', 'wamid', 'coba', 'kode_galat', 'pesan_galat',
      'dikirim', 'diterima', 'dibaca', 'gagal', 'kategori_harga', 'parameter',
    ]
    const garis = [kepala.join(';')]
    for (const r of semua.baris) {
      garis.push(
        [
          r.telepon,
          r.status,
          r.wamid || '',
          r.coba || 0,
          r.kodeGalat ?? '',
          r.pesanGalat || '',
          waktuLokal(r.waktu?.dikirim),
          waktuLokal(r.waktu?.diterima),
          waktuLokal(r.waktu?.dibaca),
          waktuLokal(r.waktu?.gagal),
          r.harga?.kategori || '',
          (r.bernama ? JSON.stringify(r.bernama) : (r.params || []).join(' | ')),
        ].map(kolomCsv).join(';')
      )
    }
    const namaBerkas = `laporan-${kampanye.nama.replace(/[^\w\-]+/g, '-').toLowerCase()}-${id}.csv`
    return new Response('﻿' + garis.join('\n'), {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${namaBerkas}"`,
        'Cache-Control': 'no-store',
      },
    })
  }

  const limit = Math.min(Number(url.searchParams.get('limit') || 100), 500)
  const offset = Math.max(Number(url.searchParams.get('offset') || 0), 0)
  const hasil = await daftarPenerima(id, { status, limit, offset })
  return jsonOk(hasil)
})
