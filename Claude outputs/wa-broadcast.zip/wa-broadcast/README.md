# WA Broadcast

Pengiriman pesan WhatsApp massal (broadcast/blasting) berbasis web, dengan
**dua jalur pengiriman yang bisa ditukar lewat satu variabel `.env`**:

| `PENGIRIM=` | Jalur | Isi pesan | Biaya |
| --- | --- | --- | --- |
| **`fonnte`** (bawaan) | Gateway Fonnte (tidak resmi) | teks bebas berplaceholder | langganan bulanan, tanpa biaya per pesan |
| `meta` | WhatsApp Business Cloud API resmi | wajib template disetujui Meta | per pesan terkirim |

Antrean, jeda kirim, percobaan ulang, laporan status, daftar tolak kirim, dan
dashboard **sama untuk keduanya** — pindah jalur tidak menyentuh berkas lain.

Backend: **Next.js (App Router, route handler)** + **Upstash Redis**.
Dashboard admin: **satu berkas HTML + Tailwind**, tanpa langkah build untuk UI.

```
Admin (browser)                 Server                        Fonnte / Meta
─────────────────               ─────────────────────         ──────────────
susun pesan     ──────────────► POST /api/pesan
unggah kontak   ──────────────► POST /api/contacts/parse
buat kampanye   ──────────────► POST /api/campaigns
                                  └─ antrean (Redis list)
                                       │
                                  dispatcher (worker / cron / tombol)
                                       ├─ jeda acak 10–20 detik antar pesan
                                       ├─ jaga 1 pesan / 6 detik per nomor
                                       ├─ isi placeholder per penerima
                                       └─ POST api.fonnte.com/send ─────────►
                                          (atau /{PHONE_ID}/messages)  │
                                                                       │
status realtime ◄─ GET /api/campaigns/{id} ◄─ POST /api/webhook/fonnte ◄┘
                                              (sent/delivered/read/failed)
```

## Isi

- [Mulai cepat](#mulai-cepat)
- [Mencoba tanpa akun Meta](#mencoba-tanpa-akun-meta)
- [Dua mode pengiriman](#dua-mode-pengiriman)
- [Struktur berkas](#struktur-berkas)
- [Daftar endpoint](#daftar-endpoint)
- [Menaikkan ke produksi](#menaikkan-ke-produksi)
- [Keamanan](#keamanan)
- [Yang perlu diketahui soal biaya & batas Meta](#yang-perlu-diketahui-soal-biaya--batas-meta)
- [Menyambungkan ke aplikasi lain](#menyambungkan-ke-aplikasi-lain)

Panduan terpisah:

- **[docs/PANDUAN-FONNTE.md](docs/PANDUAN-FONNTE.md)** — menyiapkan token Fonnte,
  memasang webhook berkunci, menulis pesan berplaceholder, jeda kirim, dan
  penggolongan kegagalan Fonnte. **Mulai dari sini** kalau memakai Fonnte.
- **[docs/PANDUAN-META.md](docs/PANDUAN-META.md)** — langkah demi langkah mendapatkan
  Phone Number ID, WABA ID, access token permanen (System User), dan memasang webhook.
- **[docs/ARSITEKTUR.md](docs/ARSITEKTUR.md)** — skema data, alur antrean, penanganan
  kesalahan, dan alasan di balik keputusan rancangannya.
- **[docs/RENCANA-MERGER-LAZDIGITAL.md](docs/RENCANA-MERGER-LAZDIGITAL.md)** — cara
  menyatukan fitur ini ke LAZDigital: login ikut website, data di kunci Redis
  terpisah, buku kontak sendiri.

---

## Mulai cepat

Syarat: Node.js 20 atau lebih baru.

```bash
npm install
copy .env.example .env.local      # Windows;  cp di macOS/Linux
npm run sandi -- "SandiAnda123"   # salin hasilnya ke ADMIN_PASSWORD_HASH
npm run css                       # bangun public/tailwind.css (sekali saja)
npm run dev                       # buka http://localhost:3000
```

Isi `.env.local` seperlunya. Yang wajib sebelum bisa mengirim:

**Kalau `PENGIRIM=fonnte` (bawaan):**

| Variabel | Isinya |
| --- | --- |
| `FONNTE_TOKEN` | Token dari dashboard Fonnte → Device → Token |
| `FONNTE_WEBHOOK_SECRET` | Rahasia karangan sendiri, ditempel di URL webhook sebagai `?kunci=` |
| `WA_JEDA_MIN_DETIK` / `WA_JEDA_MAX_DETIK` | Jeda acak antar pesan; 10 dan 20 disarankan |
| `ADMIN_PASSWORD_HASH` | Hasil `npm run sandi` |
| `SESSION_SECRET` | Teks acak ≥ 32 karakter |

**Kalau `PENGIRIM=meta`:**

| Variabel | Isinya |
| --- | --- |
| `WA_ACCESS_TOKEN` | Access token System User (permanen) |
| `WA_PHONE_NUMBER_ID` | ID nomor pengirim |
| `WA_BUSINESS_ACCOUNT_ID` | WABA ID, untuk menarik daftar template |
| `WA_APP_SECRET` | Untuk memverifikasi tanda tangan webhook |
| `WA_WEBHOOK_VERIFY_TOKEN` | Kata sandi bebas, harus sama dengan yang diketik di Meta |
| `ADMIN_PASSWORD_HASH` | Hasil `npm run sandi` |
| `SESSION_SECRET` | Teks acak ≥ 32 karakter |

Halaman **Sistem** di dashboard menampilkan variabel mana yang masih kosong,
jadi tidak perlu menebak.

> Catatan: pemisah di `ADMIN_PASSWORD_HASH` memakai titik dua (`scrypt:...:...`),
> bukan `$`. Next.js memperlakukan `$NAMA` di berkas `.env` sebagai rujukan
> variabel dan akan mengosongkannya.

---

## Mencoba tanpa akun Meta

Ada tiruan Graph API di `tools/mock-graph-server.mjs`, lengkap dengan webhook
status tiruan. Jadi seluruh alur bisa dicoba dan diuji tanpa biaya dan tanpa
mengirim pesan sungguhan.

Tiruan tersedia untuk **kedua** jalur pengiriman, lengkap dengan webhook status
tiruan — jadi seluruh alur bisa diuji tanpa biaya, tanpa nomor sungguhan, dan
tanpa risiko banned.

```bash
# jalur Fonnte (bawaan)
npm run mock       # terminal 1 — tiruan api.fonnte.com di :4030
npm run dev        # terminal 2 — aplikasi di :3000
npm run uji        # terminal 3 — 39 pemeriksaan otomatis

# jalur Meta resmi
npm run mock:meta  # tiruan Graph API di :4010
npm run uji:meta   # 49 pemeriksaan otomatis
```

Di `.env.local` cukup setel `FONNTE_BASE_URL=http://127.0.0.1:4030`
(atau `WA_GRAPH_BASE_URL=http://127.0.0.1:4010` untuk jalur Meta) dan
`STORE_DRIVER=memory`.

Nomor uji yang perilakunya sengaja dibuat sulit:

| Nomor berakhiran | Fonnte | Meta |
| --- | --- | --- |
| `999` | `target invalid` — gagal permanen | kode `131026` |
| `888` | terkirim, lalu webhook `failed` | terkirim, lalu webhook `failed` |
| `777` | `insufficient quota` — kampanye ditahan | — |

Saklar tambahan: `MOCK_FONNTE_DISCONNECT=true` (perangkat terputus),
`MOCK_FONNTE_QUOTA=<n>`, `MOCK_FONNTE_GAGAL_TIAP=<n>` (uji percobaan ulang),
`MOCK_RATE_LIMIT_EVERY=3` (uji `130429` di jalur Meta).

Berkas contoh kontak: `contoh/kontak-contoh.csv`.

Untuk menguji driver Upstash tanpa akun Upstash, ada tiruannya juga:

```bash
node tools/mock-upstash-server.mjs        # :4020
# lalu: STORE_DRIVER=upstash, UPSTASH_REDIS_REST_URL=http://127.0.0.1:4020
```

Berkas uji `npm run uji` sudah dijalankan pada kedua driver dan lulus 49/49.

---

## Dua mode pengiriman

Pengiriman **tidak pernah** dilakukan di dalam permintaan HTTP dari dashboard —
kalau begitu, kampanye 5.000 nomor akan kena timeout. Kampanye hanya menaruh
pekerjaan di antrean; yang mengirim adalah dispatcher.

### 1. Worker (komputer sendiri / VPS)

```bash
npm run worker
```

Proses jalan terus, mengirim seketika setelah kampanye dibuat.

- `STORE_DRIVER=upstash` → worker membaca antrean Redis langsung. Boleh
  dijalankan di beberapa mesin sekaligus; kunci dispatcher mencegah dobel kirim.
- `STORE_DRIVER=memory` → worker **menitip** pekerjaan lewat
  `POST /api/cron/dispatch` ke web app, karena penyimpanan mode lokal hidup di
  dalam satu proses. Butuh `CRON_SECRET` dan web app sedang hidup.

### 2. Cron (serverless / Vercel)

`vercel.json` sudah memasang cron tiap menit ke `/api/cron/dispatch`. Satu
invokasi bekerja selama `WA_DISPATCH_BUDGET_SECONDS` (bawaan 45 detik) lalu
berhenti dengan sopan; sisanya dilanjutkan invokasi berikutnya.

Di dashboard juga ada tombol **"Jalankan dispatcher sekarang"** untuk mendorong
antrean secara manual — praktis saat menguji atau saat tidak ingin menunggu cron.

---

## Struktur berkas

```
lib/
  env.js            baca .env satu pintu + pemeriksa kesiapan konfigurasi
  pengirim/
    index.js        pemilih driver (PENGIRIM=fonnte | meta)
    fonnte.js       klien Fonnte: kirim, cek perangkat & kuota, golongkan galat
    meta.js         pembungkus tipis di atas whatsapp.js
  pesan.js          pustaka pesan tersimpan + pengisian placeholder
  webhook-fonnte.js verifikasi ?kunci= + pemetaan status Fonnte
  store/
    index.js        pabrik driver + peta kunci penyimpanan
    memory.js       driver mode lokal (berkas .data/db.json)
    upstash.js      driver produksi (Upstash Redis REST)
  auth.js           sandi scrypt, sesi ber-tanda tangan, kunci gagal login
  kontak.js         pembaca CSV/TSV/tempelan/Excel, normalisasi nomor, opt-out
  whatsapp.js       klien Graph API: susun payload, kirim, golongkan kesalahan
  queue.js          antrean siap + antrean tertunda (backoff)
  ratelimit.js      jeda acak antar pesan, jeda 6 detik per nomor, kunci dispatcher
  dispatcher.js     inti pengiriman: klaim → throttle → kirim → retry
  kampanye.js       kampanye, penerima, penghitung status, transisi
  webhook.js        verifikasi tanda tangan + pemroses status
app/api/            route handler (lihat daftar endpoint)
public/app.html     dashboard admin (satu berkas)
worker/worker.mjs   dispatcher jalan terus
tools/              tiruan Graph API, tiruan Upstash, pembuat hash sandi, uji e2e
docs/               panduan Meta + arsitektur
```

---

## Daftar endpoint

| Metode | Jalur | Guna |
| --- | --- | --- |
| `POST` | `/api/auth/login` | masuk (cookie sesi HttpOnly) |
| `POST` | `/api/auth/logout` | keluar |
| `GET` | `/api/auth/me` | sesi + setelan yang aman ditampilkan |
| `GET` | `/api/perangkat` | keadaan pengirim: tersambung, sisa kuota, masa aktif |
| `GET` | `/api/pesan` | pustaka pesan tersimpan |
| `POST` | `/api/pesan` | simpan/perbarui pesan; `?aksi=periksa` untuk memeriksa saja |
| `GET`/`DELETE` | `/api/pesan/{id}` | ambil / hapus satu pesan tersimpan |
| `GET` | `/api/templates` | daftar template `APPROVED` (kosong di mode Fonnte) |
| `POST` | `/api/contacts/parse` | CSV/XLSX (`multipart`, field `berkas`) atau `{ "teks": "…" }` |
| `GET` | `/api/campaigns` | daftar kampanye + ringkasan status |
| `POST` | `/api/campaigns` | buat kampanye, masukkan ke antrean |
| `GET` | `/api/campaigns/{id}` | rincian + penghitung |
| `GET` | `/api/campaigns/{id}/recipients` | daftar penerima (`?status=gagal`, `?format=csv`) |
| `POST` | `/api/campaigns/{id}/actions` | `tahan` \| `lanjutkan` \| `batalkan` \| `ulangi-gagal` |
| `GET`/`POST` | `/api/cron/dispatch` | jalankan dispatcher (Bearer `CRON_SECRET` atau sesi admin) |
| `GET` | `/api/webhook` | handshake verifikasi Meta |
| `POST` | `/api/webhook` | kejadian status & pesan masuk (Meta) |
| `POST` | `/api/webhook/fonnte` | status & balasan dari Fonnte (butuh `?kunci=`) |
| `GET`/`POST`/`DELETE` | `/api/optout` | daftar tolak kirim |
| `GET` | `/api/logs/webhook` | 200 kejadian webhook terakhir |
| `GET` | `/api/health` | keadaan penyimpanan, antrean, kesiapan konfigurasi |

Semua endpoint kecuali `/api/webhook`, `/api/health`, dan `/api/cron/dispatch`
(dengan `CRON_SECRET`) mewajibkan sesi admin.

---

## Menaikkan ke produksi

1. Buat database **Upstash Redis**, lalu isi `UPSTASH_REDIS_REST_URL` dan
   `UPSTASH_REDIS_REST_TOKEN`, dan setel `STORE_DRIVER=upstash`.
   Jangan pakai `memory` di Vercel — tiap instance punya memori sendiri.
2. `npm run css` lalu commit `public/tailwind.css` (dashboard tidak memanggil CDN).
3. Deploy ke Vercel. Masukkan seluruh isi `.env.local` sebagai Environment
   Variables di proyek Vercel.
4. Pasang webhook di Meta ke `https://domain-anda/api/webhook` dengan verify
   token yang sama seperti `WA_WEBHOOK_VERIFY_TOKEN`, lalu berlangganan field
   **messages**.
5. Cron sudah ada di `vercel.json`. Pastikan `CRON_SECRET` terisi.
6. Mulai dari `WA_MESSAGES_PER_SECOND` yang kecil (5–10) untuk nomor baru,
   naikkan setelah mutu nomor terbukti hijau.

---

## Keamanan

- Kredensial hanya dibaca lewat `lib/env.js`; access token tidak pernah dikirim
  ke browser. Balasan `/api/auth/me` sengaja hanya memuat setelan yang aman dilihat.
- Sandi admin disimpan sebagai hash **scrypt** bergaram, bukan teks polos.
- Sesi: cookie `HttpOnly; SameSite=Lax` (+`Secure` di produksi) berisi id sesi
  dan tanda tangan HMAC; data sesinya di penyimpanan, bukan di cookie.
- Gagal login dikunci bertingkat per username **dan** per IP: 5× = 1 menit,
  8× = 5 menit, 12× = 30 menit. Pesan gagalnya seragam supaya tidak
  membocorkan username mana yang ada.
- Webhook: `GET` diverifikasi dengan verify token, `POST` diverifikasi dengan
  HMAC SHA-256 `X-Hub-Signature-256` atas **badan mentah** permintaan, dibandingkan
  secara timing-safe. Permintaan tak bertanda tangan ditolak `401`
  (dilewati hanya di mode lokal tanpa `WA_APP_SECRET`, untuk keperluan tiruan).
- `/api/cron/dispatch` butuh `Bearer CRON_SECRET` atau sesi admin.
- Nomor telepon disamarkan di log server (`62812****890`).
- Kesalahan tak terduga tidak menampilkan stack trace ke browser.

---

## Catatan memakai Fonnte

Fonnte itu gateway **tidak resmi**: nomor Anda dikendalikan lewat sesi WhatsApp
Web di server mereka. Murah, bebas template, dan melanggar ketentuan layanan
WhatsApp. Tiga hal yang perlu dipegang:

- **Pakai nomor terpisah.** Kalau kena banned tidak ada jalur banding, jadi
  jangan memakai nomor yang tercetak di kwitansi atau brosur lembaga.
- **Fonnte memegang sesi nomor itu**, jadi mereka secara teknis bisa membaca
  dan mengirim apa pun darinya. Perlakukan sebagai nomor koordinasi.
- **Jeda kirim adalah pengamannya.** Bawaan 10–20 detik acak. Menurunkannya
  memang lebih cepat, dan memang itu yang paling sering membuat nomor ditandai
  spam.

Aturan praktis yang dipakai proyek ini: **ke donatur** lewat API resmi
(`PENGIRIM=meta`), **ke pengurus KLL/ULL** lewat Fonnte di nomor terpisah.
Kampanye menyimpan pengirimnya masing-masing, jadi keduanya bisa hidup
berdampingan dan laporan lama tetap terbaca benar.

## Yang perlu diketahui soal biaya & batas Meta

Ini bagian yang paling sering membuat kaget setelah aplikasi jadi:

- **Broadcast hanya bisa memakai template yang sudah disetujui.** Pesan bebas
  hanya boleh dikirim di dalam jendela layanan 24 jam setelah pengguna membalas.
- **Sejak 1 Juli 2025 tagihannya per pesan**, bukan per percakapan. Template
  **Marketing** selalu ditagih; **Utility** dan **Authentication** ditagih bila
  dikirim di luar jendela layanan pelanggan; kategori **Service** gratis.
  Tarifnya berbeda per negara — periksa
  [halaman harga resmi](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing).
- **Throughput** bawaan Cloud API 80 pesan/detik per nomor, bisa naik otomatis
  sampai 1.000 pesan/detik. Melewati batas → kode `130429`.
- **Batas per pasangan nomor**: 1 pesan setiap 6 detik ke nomor penerima yang
  sama. Melewati batas → kode `131056`.
- **Batas jumlah penerima unik per 24 jam** bertingkat, mulai dari 250 untuk
  portofolio bisnis baru dan naik sendiri bila mutu pesan terjaga dan pemakaian
  ≥ 50% batas dalam 7 hari terakhir.
- **Mutu nomor bisa turun** kalau banyak penerima memblokir atau melaporkan.
  Karena itu aplikasi ini menyediakan daftar tolak kirim otomatis (balasan
  "STOP"/"BERHENTI") dan menahan kampanye sendiri saat Meta membalas kode yang
  menandakan masalah mutu (`131048`, `131049`).

Aplikasi ini menjaga ketiga batas teknis di atas secara bawaan, tetapi mutu
daftar kontak tetap tanggung jawab pengirim: kirim hanya ke nomor yang benar-benar
memberi izin.

---

## Menyambungkan ke aplikasi lain

Karena antarmukanya berupa HTTP JSON, aplikasi lain (mis. LAZDigital atau
aplikasi Google Apps Script) bisa memanggil `POST /api/campaigns` langsung.
Yang perlu ditambahkan hanya cara autentikasi antar-mesin — pola yang paling
ringan: satu variabel `API_KEY` di `.env.local` dan pemeriksaan header
`X-Api-Key` di `lib/http.js`, di samping pemeriksaan sesi yang sudah ada.

Bentuk badan permintaannya persis seperti yang dipakai dashboard — contoh
lengkapnya ada di komentar kepala berkas `app/api/campaigns/route.js`.
