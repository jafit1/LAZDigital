/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Dashboard-nya berkas statis di /public — tidak ada langkah build untuk UI.
  async rewrites() {
    return [{ source: '/', destination: '/app.html' }]
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
    ]
  },
}

export default nextConfig
