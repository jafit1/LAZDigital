# Panduan Fonnte

Fonnte adalah **WhatsApp gateway tidak resmi**: nomor Anda di-scan QR di server
Fonnte, lalu dikendalikan seperti WhatsApp Web. Karena itu tidak ada template
yang harus disetujui Meta, tidak ada biaya per pesan, dan isi pesannya bebas.

Konsekuensinya juga nyata, dan sudah disepakati sebelum kode ini dibuat:

- Ini melanggar ketentuan layanan WhatsApp. Kalau nomor kena banned, tidak ada
  jalur banding. Karena itu jangan memakai nomor yang tercetak di kwitansi,
  brosur, atau papan nama lembaga.
- Fonnte memegang sesi WhatsApp nomor itu, jadi secara teknis mereka bisa
  membaca dan mengirim apa pun dari nomor tersebut. Perlakukan sebagai nomor
  koordinasi, bukan nomor pemegang data donatur.
- Tidak ada persetujuan template, jadi satu-satunya penjaga mutu adalah Anda:
  daftar penerima yang izin, isi pesan yang wajar, dan jeda kirim yang tidak
  seperti robot.

Aplikasi ini memaksakan tiga pengaman terakhir itu secara bawaan.

---

## 1. Menyiapkan akun Fonnte

1. Daftar di <https://fonnte.com>, lalu tambahkan **Device** baru.
2. Scan QR dari WhatsApp di nomor yang akan dipakai mengirim.
   Nomor ini sebaiknya SIM prabayar terpisah, bukan nomor utama lembaga.
3. Buka **Device → Token**, salin tokennya. → `FONNTE_TOKEN`
4. Pastikan paketnya cukup: paket gratis Fonnte memberi 1.000 pesan, paket
   berbayar mulai puluhan ribu rupiah per bulan sampai unlimited teks.

Token Fonnte dipakai **tanpa** prefix `Bearer` — aplikasi ini sudah
mengirimkannya dalam bentuk yang benar. Kalau tiruan lokal menolak dengan
pesan "jangan pakai prefix Bearer", berarti ada yang salah di sisi klien.

---

## 2. Mengisi `.env.local`

```env
PENGIRIM=fonnte
FONNTE_TOKEN=<token dari dashboard Fonnte>
FONNTE_BASE_URL=https://api.fonnte.com
FONNTE_COUNTRY_CODE=62
FONNTE_TYPING=true
FONNTE_WEBHOOK_SECRET=<karang sendiri, acak & panjang>

# Jeda acak antar pesan — pengendali risiko banned yang paling utama
WA_JEDA_MIN_DETIK=10
WA_JEDA_MAX_DETIK=20
WA_MAX_ATTEMPTS=4
```

Angka 10–20 detik itu setara ±180–360 pesan per jam. Untuk 50 pesan sehari,
satu kampanye selesai dalam 10–15 menit. Menurunkannya di bawah 5 detik akan
memunculkan peringatan di dashboard, dan memang sebaiknya tidak dilakukan.

---

## 3. Memasang webhook

Fonnte **tidak** menandatangani permintaan webhook-nya (tidak ada padanan
`X-Hub-Signature-256` seperti Meta). Karena itu keasliannya dijaga dengan
rahasia di URL. Pasang alamat ini di dashboard Fonnte:

```
https://domain-anda.com/api/webhook/fonnte?kunci=<FONNTE_WEBHOOK_SECRET>
```

pada **dua** tempat:

| Webhook Fonnte | Gunanya di aplikasi ini |
| --- | --- |
| Update Message Status | status terkirim / diterima / dibaca / gagal per pesan |
| Reply Message | menangkap balasan **STOP** → masuk daftar tolak kirim otomatis |

Menguji dari browser: buka URL itu dengan metode GET. Kalau kuncinya benar,
balasannya `{"ok":true,...}`; kalau salah, `401`.

> Karena kuncinya ikut di URL, jangan memakai nilai yang sama dengan
> `CRON_SECRET` atau `SESSION_SECRET`.

### Kalau status pesan tidak pernah berubah

Fonnte tidak menerbitkan daftar baku nilai `status`/`state`, dan nilainya
pernah berubah antar versi. Aplikasi ini mencocokkan dengan kata kunci
(`sent`, `delivered`, `read`, `failed`, dan padanan Indonesianya), lalu
**mencatat nilai yang tidak dikenal** alih-alih menebak.

Jadi kalau status berhenti di "terkirim" padahal pesan sudah dibaca, buka tab
**Sistem → Kejadian webhook terakhir**. Nilai mentahnya ada di situ; tambahkan
polanya di `petakanStatusFonnte()` pada `lib/webhook-fonnte.js`.

---

## 4. Menulis pesan

Fonnte tidak punya template, jadi isi pesan disusun di langkah 1 dashboard:

- Placeholder memakai kurung kurawal tunggal: `{nama}`, `{nominal}`, `{program}`.
  Nama placeholder mengikuti **header berkas kontak** yang Anda unggah.
  Pencocokannya longgar — `{nama_donatur}` cocok dengan kolom "Nama Donatur".
- `{{1}}` dan `{{2}}` juga masih diterima, supaya pesan lama bergaya template
  Meta tetap terpakai.
- Placeholder yang tidak punya pasangan kolom **ditolak sebelum kirim**, bukan
  dibiarkan terkirim sebagai teks mentah. Pratinjau di sebelahnya memakai data
  kontak pertama yang sungguhan.
- Pesan bisa disimpan ke **pustaka pesan** supaya kiriman rutin tidak ditulis
  ulang tiap bulan.
- Lampiran diisi sebagai URL publik (gambar/PDF). Fonnte yang mengunduhnya,
  jadi alamatnya harus bisa diakses dari internet.

Placeholder diisi **di aplikasi ini**, bukan diserahkan ke fitur `{name}`
Fonnte. Itu sengaja: satu panggilan API = satu penerima, sehingga id pesan
yang dibalas Fonnte bisa dipetakan tepat ke satu penerima dan laporan
statusnya akurat.

Satu baris yang sebaiknya selalu ada di akhir pesan:

```
Balas STOP untuk berhenti menerima pesan.
```

Dashboard mengingatkan kalau baris itu tidak ada. Pembalas STOP otomatis masuk
daftar tolak kirim dan dilewati di kampanye berikutnya — ini penjaga mutu nomor
yang paling murah.

---

## 5. Penggolongan kegagalan Fonnte

`lib/pengirim/fonnte.js` menggolongkan balasan Fonnte menjadi tiga kelas,
sama seperti driver Meta:

| Kelas | Contoh balasan Fonnte | Tindakan |
| --- | --- | --- |
| **tahan** | `token invalid`, `insufficient quota`, `device disconnect`, `expired`, `banned` | seluruh kampanye ditahan dan alasannya dicatat |
| **sementara** | `too many request`, `url unreachable`, HTTP 5xx, timeout | ditunda dengan backoff, maksimal `WA_MAX_ATTEMPTS` percobaan |
| **permanen** | `target invalid`, `input invalid` | penerima ditandai gagal, tidak diulang |

Kelas **tahan** itu yang penting: kuota habis atau perangkat terputus tidak
akan membaik dengan diulang, dan memaksa kirim saat perangkat baru tersambung
justru pola yang mencurigakan.

Sebelum kampanye dijalankan, dashboard memanggil `/api/perangkat` dan
menampilkan nomor, status sambungan, sisa kuota, dan masa aktif paket di pojok
kanan atas. Kalau perangkat terputus, peringatannya muncul sebelum Anda menekan
kirim, bukan setelah 200 pesan gagal.

---

## 6. Mencoba tanpa Fonnte sungguhan

Ada tiruan API Fonnte lengkap dengan webhook status:

```bash
npm run mock     # tiruan Fonnte di :4030
npm run dev      # aplikasi di :3000
npm run uji      # 39 pemeriksaan otomatis
```

Setel `FONNTE_BASE_URL=http://127.0.0.1:4030` di `.env.local`.

Nomor uji yang perilakunya sengaja dibuat sulit:

| Nomor berakhiran | Yang terjadi |
| --- | --- |
| `999` | `target invalid` — gagal permanen |
| `888` | terkirim, lalu webhook melaporkan `failed` |
| `777` | `insufficient quota` — kampanye ditahan |

Saklar tambahan: `MOCK_FONNTE_DISCONNECT=true` (perangkat terputus),
`MOCK_FONNTE_QUOTA=<n>` (sisa kuota), `MOCK_FONNTE_GAGAL_TIAP=<n>` (uji
percobaan ulang).

---

## 7. Pindah ke API resmi nanti

Satu variabel:

```env
PENGIRIM=meta
```

Antrean, jeda, percobaan ulang, laporan status, pustaka kontak, dan daftar
tolak kirim tidak berubah. Yang berubah hanya dua hal:

1. Dashboard menampilkan pemilih template dan pemetaan variabel, bukan composer.
2. Kampanye lama bermode `pesan` tidak bisa dilanjutkan lewat jalur Meta —
   pesan teks bebas hanya boleh di dalam jendela 24 jam, sementara broadcast
   selalu di luar jendela itu. Aplikasi menolak dengan keterangan jelas
   alih-alih mengirim sesuatu yang pasti ditolak Meta.

Kampanye menyimpan pengirimnya masing-masing, jadi laporan kampanye lama tetap
terbaca benar setelah pindah jalur.
