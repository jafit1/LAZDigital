# Arsitektur & skema data

## 1. Kenapa berbentuk seperti ini

Tiga kendala yang membentuk seluruh rancangan:

1. **Permintaan HTTP tidak boleh dipakai mengirim pesan.** Kampanye 5.000 nomor
   pada 10 pesan/detik butuh 8 menit — jauh melewati batas waktu fungsi
   serverless. Karena itu `POST /api/campaigns` hanya menulis data dan menaruh
   pekerjaan di antrean, lalu langsung membalas.
2. **Meta punya tiga batas berbeda** (throughput per nomor, 1 pesan/6 detik per
   pasangan nomor, dan batas penerima unik per 24 jam). Melewatinya bukan hanya
   membuat pesan gagal, tetapi menurunkan mutu nomor — yang efeknya jangka
   panjang. Jadi penahan laju harus ada di jalur kirim, bukan opsional.
3. **Serverless tidak bisa menjaga proses.** BullMQ butuh proses worker yang
   hidup terus dan koneksi TCP ke Redis; keduanya tidak ada di Vercel. Maka
   antreannya dibuat model **tarik** (pull): dispatcher yang dipanggil ulang
   akan mengambil pekerjaan berikutnya. Model yang sama dipakai oleh worker
   jalan-terus di VPS — satu kode, dua cara menjalankan.

Buntutnya, `lib/dispatcher.js` adalah satu-satunya tempat yang mengirim pesan,
dan ia bisa dipanggil dari cron maupun dari worker.

---

## 2. Alur data

```
                     ┌──────────────────────────────────────────┐
                     │  DASHBOARD (public/app.html)             │
                     └───────┬──────────────────────────────────┘
                             │ 1. GET /api/templates
                             │ 2. POST /api/contacts/parse   (CSV/XLSX/tempelan)
                             │ 3. POST /api/campaigns
                             ▼
   ┌────────────────────────────────────────────────────────────────────┐
   │ lib/kampanye.js  buatKampanye()                                    │
   │   • normalisasi nomor + buang kembar (lib/kontak.js)               │
   │   • saring daftar tolak kirim                                      │
   │   • tulis kampanye, penerima, penghitung status                    │
   │   • RPUSH pekerjaan ke antrean                                     │
   └───────────────────────────────┬────────────────────────────────────┘
                                   │
        ┌──────────────────────────┴──────────────────────────┐
        │                                                     │
   Vercel Cron (tiap menit)                        worker (jalan terus)
   POST /api/cron/dispatch                         npm run worker
        │                                                     │
        └──────────────────────────┬──────────────────────────┘
                                   ▼
   ┌────────────────────────────────────────────────────────────────────┐
   │ lib/dispatcher.js  jalankanDispatcher()                            │
   │   kunci dispatcher tunggal (SET NX PX)                             │
   │   ulangi sampai anggaran waktu habis:                              │
   │     promosikan pekerjaan tertunda yang sudah waktunya              │
   │     LPOP sejumlah pekerjaan                                        │
   │     untuk tiap pekerjaan:                                          │
   │       jeda nomor 6 detik  ──belum boleh──► tunda 6 detik           │
   │       jatah pesan/detik   ──habis───────► kembalikan + tidur       │
   │       POST /{PHONE_ID}/messages                                    │
   │         sukses    → status "terkirim", simpan wamid                │
   │         sementara → tunda dengan backoff (maks 4 percobaan)        │
   │         permanen  → status "gagal"                                 │
   │         berbahaya → TAHAN seluruh kampanye                         │
   └───────────────────────────────┬────────────────────────────────────┘
                                   │ Meta memproses
                                   ▼
   ┌────────────────────────────────────────────────────────────────────┐
   │ POST /api/webhook   (lib/webhook.js)                               │
   │   verifikasi HMAC SHA-256 atas badan MENTAH                        │
   │   wamid → cari kampanye+penerima → perbarui status                 │
   │   pesan masuk berisi "STOP"/"BERHENTI" → masuk daftar tolak kirim  │
   └────────────────────────────────────────────────────────────────────┘
```

---

## 3. Skema data

Penyimpanannya Redis (Upstash) — bukan SQL. Alasannya: bebannya berupa
penghitung yang naik-turun cepat dan antrean, dua hal yang justru merepotkan
di SQL, dan Upstash bisa dipanggil lewat HTTP dari serverless.

Semua kunci berawalan `wab:` (`STORE_PREFIX`). Peta kuncinya terkumpul di satu
tempat: objek `k` di `lib/store/index.js`.

### Kampanye

| Kunci | Tipe | Isi |
| --- | --- | --- |
| `wab:kampanye:{kid}` | string (JSON) | metadata kampanye |
| `wab:kampanye:indeks` | zset | `kid`, skor = waktu dibuat (untuk daftar terbaru) |
| `wab:kampanye:{kid}:stat` | hash | penghitung per status |

```jsonc
// wab:kampanye:k_mtve...
{
  "id": "k_mtve...",
  "nama": "Laporan Donasi September",
  "status": "berjalan",              // berjalan | ditahan | selesai | dibatalkan
  "template": {
    "nama": "kabar_program",
    "bahasa": "id",
    "kategori": "UTILITY",           // menentukan biaya
    "bernama": false,                // true bila template pakai {{nama}}
    "variabel": ["1", "2", "3"],
    "teksBody": "Assalamualaikum {{1}}, ..."
  },
  "headerTetap": null,               // { tipe: "image", nilai: "https://..." }
  "dibuatOleh": "admin",
  "dibuatPada": 1789037364386,
  "diperbaruiPada": 1789037399001,
  "jumlahPenerima": 1200,
  "catatanTahan": null               // alasan bila ditahan otomatis
}
```

Isi hash `stat`: `total`, `antre`, `terkirim`, `diterima`, `dibaca`, `gagal`,
`dilewati`, `dibatalkan`. Dipakai `HINCRBY` supaya beberapa worker boleh
menulis bersamaan tanpa saling menimpa.

### Penerima (satu baris = satu pesan)

| Kunci | Tipe | Isi |
| --- | --- | --- |
| `wab:penerima:{kid}:{rid}` | string (JSON) | satu baris penerima |
| `wab:penerima:{kid}:daftar` | list | urutan `rid` |
| `wab:penerima:{kid}:st:{status}` | list | `rid` per status, untuk saringan cepat |

```jsonc
{
  "id": "000042",
  "kid": "k_mtve...",
  "telepon": "6281234567890",        // E.164 tanpa "+"
  "params": ["Ahmad", "150.000", "Beasiswa Yatim"],
  "bernama": null,                   // { "nama": "Ahmad", ... } bila template bernama
  "header": null,
  "tombol": [],
  "status": "dibaca",                // antre|terkirim|diterima|dibaca|gagal|dilewati|dibatalkan
  "wamid": "wamid.HBgM...",          // kunci untuk mencocokkan webhook
  "coba": 1,
  "kodeGalat": null,
  "pesanGalat": null,
  "waktu": { "dibuat": 0, "dikirim": 0, "diterima": 0, "dibaca": 0, "gagal": null },
  "harga": { "kategori": "utility", "model": "PMP", "ditagih": true },
  "percakapan": "conv_..."
}
```

### Antrean

| Kunci | Tipe | Isi |
| --- | --- | --- |
| `wab:antrean` | list | pekerjaan siap kirim: `{ kid, rid, telepon, coba }` |
| `wab:antrean:tunda` | zset | pekerjaan tertunda, skor = waktu siap (ms epoch) |
| `wab:kunci:dispatch` | string | kunci dispatcher tunggal, ber-TTL |
| `wab:jatah:{epochDetik}` | string | penghitung pesan pada detik itu (ember token) |
| `wab:jeda:{telepon}` | string | penanda jeda 6 detik per nomor, ber-TTL |

### Lain-lain

| Kunci | Tipe | Isi |
| --- | --- | --- |
| `wab:wamid:{wamid}` | string | `"{kid}:{rid}"`, TTL 30 hari — jalan balik dari webhook |
| `wab:optout` | set | nomor yang menolak dikirimi |
| `wab:log:webhook` | list | 200 kejadian webhook terakhir (untuk penelusuran) |
| `wab:cache:template` | string (JSON) | hasil tarik template, disegarkan tiap 5 menit |
| `wab:sesi:{sid}` | string (JSON) | sesi admin, ber-TTL |
| `wab:gagal-login:{kunci}` | string | penghitung gagal login per username / IP |

### Kalau ingin memakai SQL

Skema di atas berpadanan dengan empat tabel:

```sql
kampanye   (id PK, nama, status, template_nama, template_bahasa, template_kategori,
            template_variabel JSON, dibuat_oleh, dibuat_pada, catatan_tahan)
penerima   (id PK, kampanye_id FK, telepon, params JSON, status, wamid UNIQUE,
            coba, kode_galat, pesan_galat, dikirim_pada, diterima_pada,
            dibaca_pada, gagal_pada, harga JSON,
            INDEX (kampanye_id, status), INDEX (wamid))
optout     (telepon PK, alasan, dibuat_pada)
log_webhook(id PK, pada, isi JSON)
```

Antreannya tinggal jadi `SELECT ... WHERE status='antre' AND siap_pada <= NOW()
ORDER BY id LIMIT n FOR UPDATE SKIP LOCKED`. `SKIP LOCKED` itulah yang
menggantikan kunci dispatcher.

---

## 4. Penahan laju (throttling)

Tiga penahan bekerja bersamaan di `lib/ratelimit.js`:

1. **Ember token per detik.** `INCRBY wab:jatah:{epochDetik}`; kalau hasilnya
   melewati `WA_MESSAGES_PER_SECOND`, pengirim menunggu sampai detik
   berikutnya. Karena penghitungnya di penyimpanan bersama, batasnya tetap
   benar walau dispatcher jalan di beberapa instance.
2. **Jeda per nomor penerima.** `SET wab:jeda:{telepon} NX EX 6`. Kalau gagal
   (berarti nomor itu baru dikirimi), pekerjaan ditunda 6 detik. Ini menjaga
   batas 1 pesan/6 detik per pasangan nomor — batas yang paling sering
   terlanggar saat satu nomor muncul dua kali di daftar.
3. **Kunci dispatcher tunggal.** `SET wab:kunci:dispatch NX PX`. Vercel Cron
   bisa memicu invokasi yang bertumpuk; tanpa kunci ini, satu pekerjaan bisa
   terkirim dua kali.

`WA_MESSAGES_PER_SECOND` sengaja bernilai bawaan **10**, bukan 80. Nomor baru
sebaiknya menghangat perlahan; angkanya dinaikkan setelah mutu nomor terbukti.

---

## 5. Penggolongan kesalahan Meta

`lib/whatsapp.js` menggolongkan setiap kegagalan menjadi tiga kelas, dan itulah
yang menentukan tindakan dispatcher:

| Kelas | Contoh kode | Tindakan |
| --- | --- | --- |
| **sementara** | `130429` throughput, `131056` pasangan nomor, `131057` naik kapasitas, `80007`, `4`, `613`, HTTP 5xx, timeout jaringan | tunda dengan backoff eksponensial + jitter, maksimal `WA_MAX_ATTEMPTS` percobaan |
| **permanen** | `132000` jumlah parameter, `132001` template tak ada, `131026` nomor tak terdaftar | tandai penerima `gagal`, jangan ulangi |
| **tahan** | `190` token mati, `131048`/`131049` batas spam & mutu, `368` akun dibatasi, `133010` nomor belum terdaftar | **tahan seluruh kampanye** dan catat alasannya |

Kelas **tahan** itu yang paling penting dan paling sering dilupakan: kalau Meta
mengeluh soal mutu atau token, mengulang pengiriman hanya memperburuk keadaan.
Lebih baik kampanye berhenti sendiri dan menunggu manusia memutuskan.

Backoff dihitung `dasar × 2^(percobaan-1)` dengan jitter sampai 20%, dibatasi
10 menit. Jitter perlu supaya ribuan pekerjaan yang tertunda karena rate limit
tidak kembali serentak dan langsung kena rate limit lagi.

---

## 6. Aturan status penerima

Status punya tingkat, dan pembaruan dari webhook tidak boleh **menurunkan**
tingkat — kejadian `sent` yang datang terlambat tidak boleh menimpa `dibaca`:

```
antre(0) → terkirim(2) → diterima(3) → dibaca(4)
             └──────────────┴─────────────┴───► gagal(5)
```

`gagal` diberi tingkat tertinggi karena Meta bisa mengirim `failed` **setelah**
`sent`/`delivered` (mis. perangkat penerima menolak pesan), dan kegagalan itulah
kenyataan akhirnya.

Perubahan yang dipicu manusia — misalnya "ulangi yang gagal", yang memang
menurunkan `gagal` kembali ke `antre` — memakai `{ paksa: true }` sehingga tidak
terikat aturan ini.

Karena aturan itu, pemrosesan webhook bersifat **idempoten**: kejadian yang sama
dikirim dua kali (Meta memang mengulang bila balasan kita lambat) tidak merusak
penghitung.

---

## 7. Dua driver penyimpanan

`lib/store/` memuat dua driver dengan antarmuka yang sama persis:

- **`memory.js`** — data di memori proses, ditulis ke `.data/db.json`.
  Untuk mencoba di komputer sendiri tanpa akun apa pun. **Hanya satu proses**
  yang boleh memakainya; karena itu worker mode lokal menitip pekerjaan lewat
  HTTP alih-alih menyentuh penyimpanan sendiri.
- **`upstash.js`** — Upstash Redis REST, dengan dukungan pipeline. Untuk
  produksi dan Vercel.

Berpindah di antara keduanya hanya soal `STORE_DRIVER` di `.env.local`. Tidak
ada satu pun berkas lain yang tahu bedanya — itulah gunanya pemisahan ini, dan
itu juga yang membuat `tools/mock-upstash-server.mjs` bisa menguji jalur
produksi tanpa akun Upstash.

---

## 8. Yang sengaja tidak dibuat

Supaya jelas batasnya:

- **Tidak ada pembuat template.** Template dibuat di WhatsApp Manager. Membuat
  lapisan di atasnya hanya menambah tempat rusak tanpa menambah kemampuan.
- **Tidak ada penjadwalan kampanye.** Kalau perlu, tambahkan satu zset
  `wab:jadwal` berisi kampanye ditahan beserta waktu mulai, dan biarkan
  dispatcher melanjutkannya saat waktunya tiba.
- **Tidak ada percakapan dua arah.** Pesan masuk hanya dibaca untuk menangkap
  "STOP"/"BERHENTI". Membangun inbox adalah aplikasi tersendiri.
- **Tidak ada multi-pengguna berperan.** Satu akun admin dari `.env`. Untuk
  beberapa pengurus, ganti bagian ini dengan tabel pengguna — bagian lain tidak
  perlu berubah karena semuanya lewat `wajibAdmin()` di `lib/http.js`.
