# Rencana merger ke LAZDigital

Tujuan: fitur broadcast jalan **di dalam** lazdigital.my.id — login ikut login
website, izin ikut Manajemen User — sementara datanya **tidak** ikut masuk ke
basis data LAZDigital.

Dokumen ini ditulis setelah membaca `api/rpc.js`, `api/_engine.js`, dan
`vercel.json` di D:\Project\LAZDigital.

---

## 1. Temuan yang menentukan rancangan

**LAZDigital menyimpan seluruh basis data sebagai SATU kunci Redis.**
`api/rpc.js` membaca `laz:db` (satu blob JSON) pada setiap permintaan, menjalankan
fungsi di `_engine.js`, lalu menulis ulang **seluruh blob** dengan
compare-and-set pada `laz:ver`. Kalau ada yang menulis lebih dulu, permintaan
diulang dari awal (maksimal 4 kali).

Pola itu bagus untuk aplikasi pencatatan yang dipakai beberapa petugas. Tetapi
kalau data broadcast ditaruh di dalamnya, hasilnya rusak dengan cara yang tidak
kelihatan sampai kampanye pertama jalan:

| | Kalau di dalam `laz:db` | Kalau di kunci sendiri (`wab:*`) |
| --- | --- | --- |
| Satu kabar status dari Meta (`sent`) | baca + tulis ulang **seluruh** basis data | 4–5 perintah kecil |
| 2.000 pesan × 3 status | 6.000 kali menulis ulang blob penuh | ±14 rb perintah kecil |
| Bandwidth Upstash | blob 2 MB × 6.000 = ±12 GB | beberapa MB |
| Bentrok dengan petugas yang sedang mencatat penghimpunan | terus-menerus (webhook Meta datang berbarengan) | tidak ada — kunci berbeda |
| Ukuran basis data | 5.000 penerima ±1,5 MB per kampanye, ikut dibaca di **setiap** permintaan RPC biasa | tidak menyentuh `laz:db` |

Kuota gratis Upstash 500 rb perintah dan 10 GB bandwidth per bulan. Menaruh
broadcast di dalam `laz:db` menghabiskannya dalam satu kampanye.

**Kesimpulan: berbagi login, jangan berbagi tabel.** Data broadcast tinggal di
database Upstash yang sama tetapi di kunci `wab:*` yang terpisah — persis skema
yang sudah dipakai proyek wa-broadcast.

Temuan pendukung lain:

- **Autentikasi sudah cocok.** `_engine.js` memakai token UUID di sheet
  `Sessions`; setiap fungsi RPC menerima token sebagai argumen pertama dan
  memanggil `authUser(t)` atau `_requirePerm(t, modul, aksi)`. Endpoint broadcast
  bisa memakai token yang sama — tidak perlu login kedua.
- **Sistem izin sudah ada.** `MODULES` di baris 67 `_engine.js`. Menambahkan satu
  nama modul membuat broadcast langsung muncul di Manajemen User, termasuk
  pembatasan per akun KLL yang sudah Anda punya.
- **Durasi fungsi.** `vercel.json` menyetel `api/**/*.js` ke `maxDuration: 30`.
  Paket Hobby sebenarnya mengizinkan 300 detik. Dispatcher butuh jatah lebih
  panjang (lihat §6).
- **Cron.** Sudah ada satu cron harian (`/api/backup`, 19:00 UTC = 02:00 WIB).
  Paket Hobby hanya mengizinkan cron **sekali sehari** — ini yang menentukan cara
  dispatcher dipicu.

---

## 2. Bentuk akhir

```
D:\Project\LAZDigital\
  api\
    rpc.js                 (tidak diubah — hanya ditambah 1 baris ekspor)
    _engine.js             (+1 nama modul, +1 helper izin)
    wa.js            BARU  RPC broadcast: kontak, template, kampanye, laporan
    wa-dispatch.js   BARU  pengirim antrean (CRON_SECRET / sesi admin)
    wa-webhook.js    BARU  penerima status Meta (publik, tanpa sesi)
    _wa\             BARU  salinan lib/ dari proyek wa-broadcast
      store.js  kontak.js  whatsapp.js  queue.js  ratelimit.js
      dispatcher.js  kampanye.js  webhook.js  util.js
  src\public\
    broadcast.html   BARU  dashboard broadcast (memakai token yang sudah ada)
```

Kunci Redis yang dipakai — tidak ada yang bersinggungan dengan `laz:*`:

```
wab:kontak:{id}          satu kontak (buku kontak broadcast sendiri)
wab:kontak:indeks        zset, urut waktu dibuat
wab:kontak:label:{nama}  set berisi id kontak per label
wab:kampanye:{id}        metadata kampanye
wab:kampanye:indeks      zset
wab:kampanye:{id}:stat   hash penghitung status
wab:penerima:{kid}:{rid} satu baris penerima
wab:antrean              list pekerjaan siap kirim
wab:antrean:tunda        zset pekerjaan tertunda
wab:wamid:{wamid}        pemetaan balik dari webhook
wab:optout               set nomor yang menolak
```

---

## 3. Login ikut website

Endpoint broadcast tetap memeriksa izin lewat `_engine.js`, jadi aturan akses
tidak digandakan di dua tempat.

**`api/_engine.js`** — dua sisipan kecil:

```js
/* baris 67 — tambahkan 'broadcast' di ujung */
var MODULES = ['dashboard','penghimpunan','pentasyarufan','laporan','rekening',
               'layanan','users','settings','donatur','log','saldodaerah','broadcast'];

/* di MODUL_LABEL */
broadcast: 'Broadcast WhatsApp',

/* di MODUL_KET */
broadcast: 'Mengirim pesan WhatsApp massal ke buku kontak broadcast.',

/* di bagian module.exports paling bawah — helper izin untuk endpoint di luar rpc.js */
cekIzin: function(db, token, modul, aksi){ DB = db; return _requirePerm(token, modul, aksi); },
```

**`api/rpc.js`** — cukup ekspor pembaca database dan klien Redis yang sudah ada
(baris 158 sudah mengekspor `_internal`; tambahkan `muat` dan `redis` kalau perlu
dipakai dari luar):

```js
module.exports._internal = { muat, tulisRedis, redis, PAKAI_REDIS, DB_KEY, VER_KEY };
```

**`api/wa.js`** — pola pemeriksaan izin:

```js
const engine = require('./_engine.js');
const { _internal } = require('./rpc.js');

async function izin(token, aksi){
  const r = await _internal.muat();          // 1 MGET, DB tidak pernah ditulis
  return engine.cekIzin(r.db, token, 'broadcast', aksi);
}
```

Satu `MGET` per permintaan broadcast, tanpa satu pun penulisan ke `laz:db`.
Tidak ada peluang bentrok dengan petugas yang sedang mencatat.

**`api/wa-webhook.js` tidak memanggil `izin()` sama sekali** — Meta tidak punya
sesi. Keamanannya dari tanda tangan HMAC `X-Hub-Signature-256`. Ini juga yang
membuat banjir webhook tidak pernah menyentuh `laz:db`.

**Frontend.** `src/public/app.js` sudah 473 KB; membedahnya berisiko. Cara paling
murah dan aman:

1. Taruh `broadcast.html` di `src/public/` (dashboard dari proyek wa-broadcast,
   dengan layar login dibuang).
2. Halaman itu membaca token dari `localStorage` — kunci yang sama yang dipakai
   `app.js`. Satu origin, jadi storage-nya sama.
3. Kalau token kosong atau ditolak, alihkan ke `/` supaya pengguna login lewat
   website seperti biasa.
4. Di menu `app.js`, tambahkan satu tautan "Broadcast WhatsApp" ke
   `/broadcast.html`, ditampilkan hanya bila `can(user,'broadcast','view')`.

Kalau nanti ingin benar-benar menyatu di dalam `app.js`, isi `broadcast.html`
bisa dipindahkan jadi satu halaman di router `app.js` tanpa mengubah sisi server.

---

## 4. Buku kontak sendiri, di luar tabel Donatur

Ini yang Anda minta: daftar yang bisa ditambah semau Anda, tidak terikat
transaksi.

```jsonc
// wab:kontak:{id}
{
  "id": "c_...",
  "telepon": "6281234567890",     // E.164, dinormalkan saat disimpan
  "nama": "Bapak Ahmad",
  "panggilan": "Pak Ahmad",       // dipakai sebagai parameter template
  "label": ["donatur-rutin", "kll-bantul", "muzakki-2026"],
  "kolom": {                      // bebas, jadi parameter template
    "kota": "Bantul",
    "program": "Beasiswa Yatim",
    "nominal_terakhir": "150.000"
  },
  "sumber": "impor-csv",          // impor-csv | manual | donatur-lazdigital
  "catatan": "",
  "dibuat": 1789000000000
}
```

Cara mengisinya:

- **Tambah manual** satu-satu dari dashboard.
- **Impor CSV/Excel** — parser di `lib/kontak.js` sudah menangani 08xx → 62xx,
  nomor kembar, dan pemisah titik koma dari Excel Indonesia.
- **Tarik dari Donatur LAZDigital** (satu arah, opsional): baca sheet `Donatur`
  (`id, nama, kategori, telepon, alamat, email, dibuat`), ambil yang punya
  `telepon`, tawarkan pratinjau, lalu salin ke `wab:kontak:*` dengan
  `sumber: "donatur-lazdigital"`. Salinan, bukan sambungan — mengubah kontak
  broadcast tidak menyentuh data donatur, dan sebaliknya.
- **Label** dipakai untuk memilih penerima: "kirim ke label `donatur-rutin`
  yang kotanya Bantul". Ini yang membuat segmentasi murah (lihat kalkulator biaya).

Kontak KLL/ULL sengaja tidak ditarik otomatis — aturan di LAZDigital sudah
mengecualikan mereka dari daftar donatur.

---

## 5. Kategori template menentukan tagihan

Tarif Meta untuk Indonesia per pesan terkirim: **Utility Rp 356,65** lawan
**Marketing Rp 586,33**. Selisihnya 39% untuk pesan yang sama panjang.

Maka dashboard broadcast wajib menampilkan kategori template sebelum tombol
kirim ditekan, dan buku kontak sebaiknya punya label yang memisahkan:

- **Utility** — laporan penyaluran donasi seseorang, konfirmasi kwitansi,
  pengingat kegiatan yang ia daftar sendiri. Menyusul tindakan donatur, tanpa
  ajakan berdonasi.
- **Marketing** — ajakan berdonasi, kabar program baru, undangan terbuka.

Menambahkan "yuk donasi lagi" di akhir template Utility membuat Meta berhak
menggolongkannya ulang jadi Marketing. Pisahkan dua jenis pesan itu menjadi dua
template berbeda, jangan digabung demi ringkas.

---

## 6. Cara dispatcher dipicu di Vercel Hobby

Paket Hobby membatasi cron **sekali sehari**, tetapi mengizinkan fungsi jalan
**300 detik**. Itu kombinasi yang justru menguntungkan: satu putaran dispatcher
280 detik pada 10 pesan/detik mengirim ±2.800 pesan — cukup untuk seluruh
kampanye Lazismu dalam satu invokasi.

Susunan yang dipakai, dari yang paling utama:

1. **Tombol "Kirim sekarang" di dashboard** memanggil `/api/wa-dispatch` dengan
   sesi admin. Ini jalur normal: Anda memang menunggu saat menekan kirim.
2. **Rantai otomatis.** Kalau anggaran waktu habis sementara antrean masih ada,
   fungsi memanggil dirinya sendiri sekali (fetch tanpa menunggu) dengan
   penghitung rantai maksimal, supaya kampanye besar tetap lanjut tanpa cron.
   Kunci dispatcher mencegah dua putaran berjalan bersamaan.
3. **Cron harian sebagai jaring pengaman**, digabung ke `vercel.json` yang sudah
   ada — membersihkan sisa antrean yang tertunda karena percobaan ulang.
4. **Kalau ingin antrean jalan sendiri tiap menit**, pakai layanan cron gratis
   pihak ketiga yang memanggil `/api/wa-dispatch` dengan header
   `Authorization: Bearer <CRON_SECRET>`. Tetap Rp0, tanpa naik ke Vercel Pro.

`vercel.json` — dua perubahan:

```jsonc
"functions": {
  "api/**/*.js":        { "maxDuration": 30 },
  "api/wa-dispatch.js": { "maxDuration": 300 }
},
"crons": [
  { "path": "/api/backup",      "schedule": "0 19 * * *" },
  { "path": "/api/wa-dispatch", "schedule": "30 19 * * *" }
]
```

Setel `WA_DISPATCH_BUDGET_SECONDS=280` di Environment Variables Vercel.

---

## 7. Variabel lingkungan tambahan di Vercel

Yang sudah ada (`UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`,
`CRON_SECRET`, kredensial Drive) dipakai ulang. Yang perlu ditambah:

```
WA_ACCESS_TOKEN            token System User (permanen)
WA_PHONE_NUMBER_ID
WA_BUSINESS_ACCOUNT_ID
WA_APP_SECRET
WA_WEBHOOK_VERIFY_TOKEN
WA_GRAPH_VERSION=v24.0
WA_MESSAGES_PER_SECOND=10
WA_CONCURRENCY=3
WA_SAME_NUMBER_COOLDOWN_SECONDS=6
WA_MAX_ATTEMPTS=4
WA_DISPATCH_BUDGET_SECONDS=280
STORE_DRIVER=upstash
STORE_PREFIX=wab
```

`STORE_PREFIX=wab` inilah yang menjaga pemisahan dari `laz:*`.

Webhook di Meta diarahkan ke `https://lazdigital.my.id/api/wa-webhook`,
berlangganan field **messages**.

---

## 8. Hemat kuota Upstash

Perkiraan ±25–35 perintah Redis per pesan (antre, kirim, tiga kabar status).
Pada 2.000 pesan/bulan ≈ 60 rb perintah — masih di dalam kuota gratis 500 rb,
berbagi dengan pemakaian LAZDigital sendiri. Dua penghematan mudah kalau
mendekati batas:

- **Lewati status `read`.** Sekitar sepertiga perintah webhook habis di sana,
  padahal untuk laporan penyaluran, "diterima" biasanya sudah cukup.
- **Hapus indeks per status** (`wab:penerima:{kid}:st:{status}`) dan saring di
  memori saat menampilkan laporan; kampanye Lazismu ukurannya masih ribuan baris.

Kalau tetap terlampaui, bayar-sesuai-pakai Upstash $0,2 per 100 rb perintah —
sekitar Rp3 rb, bukan angka yang perlu dihindari.

---

## 9. Urutan pengerjaan

1. Salin `lib/*` proyek wa-broadcast ke `api/_wa/`, ubah `STORE_PREFIX` ke `wab`.
2. Sisipkan `'broadcast'` ke `MODULES` + label + `cekIzin` di `_engine.js`.
3. Buat `api/wa.js` (kontak & kampanye), uji dengan tiruan Graph API dulu
   (`WA_GRAPH_BASE_URL` ke mock) di lokal.
4. Buat `api/wa-webhook.js`, uji tanda tangan HMAC-nya.
5. Buat `api/wa-dispatch.js` + rantai otomatis + kunci dispatcher.
6. Buat `src/public/broadcast.html`, sambungkan ke token `localStorage`.
7. Tambahkan tautan menu di `app.js` di belakang `can(user,'broadcast','view')`.
8. Ubah `vercel.json`, isi Environment Variables, deploy.
9. Pasang webhook di Meta, kirim satu kampanye uji ke 3 nomor sendiri.
10. Baru isi buku kontak sungguhan, dan mulai dari daftar kecil untuk menghangatkan
    nomor pengirim.

Langkah 1–5 tidak menyentuh satu pun berkas yang dipakai pencatatan Lazismu,
jadi bisa dikerjakan dan di-deploy tanpa risiko mengganggu petugas yang sedang
memakai aplikasi.
