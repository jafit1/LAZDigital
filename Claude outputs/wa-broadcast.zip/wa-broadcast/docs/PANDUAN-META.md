# Panduan pendaftaran di Meta for Developers

Tujuan akhir panduan ini: mendapatkan lima nilai untuk `.env.local`.

| Variabel | Diambil dari |
| --- | --- |
| `WA_PHONE_NUMBER_ID` | WhatsApp Manager / halaman API Setup |
| `WA_BUSINESS_ACCOUNT_ID` (WABA ID) | halaman yang sama |
| `WA_ACCESS_TOKEN` | System User di Business Settings (permanen) |
| `WA_APP_SECRET` | App Dashboard → Settings → Basic |
| `WA_WEBHOOK_VERIFY_TOKEN` | Anda karang sendiri, lalu diketik di dua tempat |

Antarmuka Meta cukup sering berubah tempat menu. Yang tidak berubah adalah
urutan langkahnya dan nama-nama objeknya, jadi kalau letak tombolnya bergeser,
cari nama objeknya.

---

## 0. Yang perlu disiapkan lebih dulu

1. **Akun Facebook** yang bisa dipakai untuk masuk ke Meta for Developers.
2. **Meta Business Account** (Business Portfolio) untuk lembaga/usaha Anda.
   Untuk lembaga seperti Muhammadiyah/Lazismu, pakai portofolio bisnis
   lembaganya — bukan akun pribadi — supaya verifikasi bisnisnya lancar.
3. **Nomor HP yang belum terpakai di aplikasi WhatsApp mana pun.** Kalau nomor
   itu sedang dipakai di WhatsApp biasa atau WhatsApp Business (aplikasi HP),
   nomornya harus dihapus dari aplikasi itu dulu. Setelah masuk Cloud API,
   nomor tersebut **tidak bisa lagi** dipakai di aplikasi WhatsApp biasa.
4. Nomor itu harus bisa menerima SMS atau panggilan untuk verifikasi.

---

## 1. Buat App di Meta for Developers

1. Buka <https://developers.facebook.com/apps> → **Create App**.
2. Pilih jenis penggunaan yang mengarah ke **Business** / **Other → Business**.
3. Hubungkan App ke **Business Portfolio** lembaga Anda (jangan dilewati —
   token permanen nantinya bergantung pada ini).
4. Di dasbor App, cari produk **WhatsApp** → **Set up**.

Setelah itu Meta membuatkan:

- satu **WhatsApp Business Account (WABA)**, dan
- satu **nomor uji** gratis yang hanya bisa mengirim ke maksimal 5 nomor
  penerima yang didaftarkan manual.

Nomor uji cocok untuk memastikan pemasangan berjalan, tetapi **tidak cocok**
untuk broadcast sungguhan.

---

## 2. Ambil Phone Number ID dan WABA ID

Masuk ke **WhatsApp → API Setup** (kadang bernama *Getting Started*).

Di sana terlihat:

- **Phone number ID** — angka panjang di bawah nomor yang dipilih.
  → `WA_PHONE_NUMBER_ID`
- **WhatsApp Business Account ID** — → `WA_BUSINESS_ACCOUNT_ID`

Yang **bukan** yang dicari: "App ID" dan nomor telepon itu sendiri.
Yang dipakai API adalah **ID**-nya, bukan nomornya.

---

## 3. Tambahkan nomor sungguhan

Di **WhatsApp Manager → Phone numbers → Add phone number**:

1. Isi nama tampilan (*display name*). Nama ini diperiksa Meta dan harus
   berhubungan dengan nama lembaga — nama yang menyesatkan akan ditolak.
2. Pilih kategori bisnis dan zona waktu.
3. Verifikasi lewat SMS atau panggilan.
4. Salin **Phone number ID** nomor baru itu.

Untuk mengirim ke penerima di luar daftar uji, portofolio bisnis Anda perlu
melewati **verifikasi bisnis** (Business Verification) — unggah dokumen
lembaga di **Business Settings → Business Info → Start Verification**.
Prosesnya bisa memakan beberapa hari kerja.

---

## 4. Access token permanen lewat System User

Token yang muncul di halaman API Setup hanya berlaku **24 jam**. Untuk
aplikasi yang jalan terus, gunakan **System User** — inilah cara resminya.

1. Buka **Business Settings** (business.facebook.com/settings) →
   **Users → System Users** → **Add**.
2. Nama: mis. `wa-broadcast-server`. Peran: **Admin** (atau Employee, lalu
   beri izin aset secara eksplisit).
3. Pilih system user itu → **Add Assets** →
   - tab **Apps**: pilih App yang dibuat di langkah 1, aktifkan
     **Manage app** (atau minimal *Develop app*),
   - tab **WhatsApp Accounts**: pilih WABA Anda, aktifkan **Full control**.
4. Klik **Generate new token**:
   - App: pilih App Anda,
   - **Token expiration: Never**,
   - centang izin:
     - `whatsapp_business_messaging` — untuk mengirim pesan,
     - `whatsapp_business_management` — untuk membaca daftar template.
5. Salin token yang muncul **sekarang** — token itu tidak bisa dilihat lagi
   setelah jendela ditutup. → `WA_ACCESS_TOKEN`

Menguji tokennya (ganti dua nilai di dalam kurung kurawal):

```bash
curl "https://graph.facebook.com/v24.0/{WABA_ID}/message_templates?limit=5" \
  -H "Authorization: Bearer {TOKEN}"
```

Kalau balasannya memuat `data: [...]`, token dan WABA ID sudah benar.
Kalau balasannya kode `190`, tokennya salah atau sudah dicabut.

> Simpan token ini seperti menyimpan kunci rumah. Siapa pun yang memegangnya
> bisa mengirim pesan atas nama lembaga Anda dan tagihannya jatuh ke Anda.
> Token hanya boleh ada di `.env.local` (yang sudah masuk `.gitignore`) atau di
> Environment Variables penyedia hosting.

---

## 5. App Secret

**App Dashboard → Settings → Basic → App Secret → Show**. → `WA_APP_SECRET`

Nilai ini dipakai memverifikasi bahwa webhook yang masuk benar-benar dari Meta
(tanda tangan `X-Hub-Signature-256`). Tanpa ini, siapa pun yang tahu URL webhook
Anda bisa mengarang status pesan.

---

## 6. Pasang webhook

Webhook adalah cara Meta memberi tahu status `sent` → `delivered` → `read` →
`failed`. Tanpa ini, dashboard hanya tahu pesan sudah diterima Meta, tidak tahu
apakah benar-benar sampai.

Server Anda harus bisa diakses dari internet dengan **HTTPS**.

1. Karang satu kata sandi bebas, mis. `token-webhook-lazismu-2026`.
   Taruh di `.env.local` sebagai `WA_WEBHOOK_VERIFY_TOKEN`, lalu jalankan/deploy
   aplikasinya (nilai ini harus sudah aktif di server sebelum langkah 3).
2. Buka **App Dashboard → WhatsApp → Configuration → Webhook → Edit**.
3. Isi:
   - **Callback URL**: `https://domain-anda.com/api/webhook`
   - **Verify token**: kata sandi yang sama seperti langkah 1
4. Klik **Verify and save**. Meta akan memanggil `GET /api/webhook` dan
   aplikasi ini membalas `hub.challenge`-nya. Kalau gagal, biasanya karena
   verify token beda atau server belum menyala.
5. Di daftar **Webhook fields**, klik **Manage** lalu **Subscribe** pada field
   **`messages`**. Field inilah yang membawa status pesan sekaligus pesan masuk.

Menguji dari komputer sendiri (belum punya domain)? Pakai penerusan seperti
`ngrok http 3000` atau `cloudflared tunnel`, lalu pakai URL HTTPS-nya sebagai
Callback URL. Untuk pengujian tanpa Meta sama sekali, pakai
`npm run mock` (lihat README).

---

## 7. Buat template pesan

Template dibuat di **WhatsApp Manager → Message templates → Create template**
(tidak bisa dibuat dari aplikasi ini — dan itu memang disengaja).

Yang perlu diperhatikan:

- **Kategori** menentukan biaya dan perlakuan Meta:
  - *Marketing* — promosi, undangan, ajakan. Selalu ditagih.
  - *Utility* — menyusul transaksi/permintaan pengguna (mis. laporan donasi,
    pengingat kegiatan yang mereka daftar). Lebih murah dan lebih aman untuk
    mutu nomor.
  - *Authentication* — khusus kode OTP.
  Salah memilih kategori bisa membuat template ditolak atau digolongkan ulang
  oleh Meta.
- **Variabel** ditulis `{{1}}`, `{{2}}`, … (berurut) atau `{{nama}}`,
  `{{kode}}`, … (bernama). Aplikasi ini mendukung keduanya dan mendeteksinya
  sendiri saat template ditarik.
- Variabel **tidak boleh** memuat baris baru, tab, atau lebih dari 4 spasi
  berurutan, dan tidak boleh kosong. `lib/whatsapp.js` sudah membersihkannya
  (nilai kosong diganti `-`).
- Persetujuan biasanya beberapa menit sampai beberapa jam. Hanya template
  berstatus **APPROVED** yang muncul di dashboard.
- Contoh template yang aman untuk laporan donasi (kategori *Utility*):

  ```
  Assalamualaikum {{1}}, terima kasih atas donasi Anda sebesar Rp{{2}}.
  Dana tersebut telah disalurkan untuk program {{3}}. Jazakumullah khairan.
  ```

  Footer yang sangat disarankan: `Balas STOP untuk berhenti menerima pesan.`
  Aplikasi ini otomatis memasukkan pembalas "STOP"/"BERHENTI" ke daftar
  tolak kirim.

---

## 8. Naikkan batas kirim

Nomor baru mulai dari batas 250 penerima unik per 24 jam. Batas naik sendiri
bila:

- mutu pesan tetap tinggi di semua nomor dan template, dan
- pemakaian mencapai setidaknya 50% batas dalam 7 hari terakhir.

Kalau syaratnya terpenuhi, kenaikan biasanya turun dalam 6 jam. Karena itu,
untuk daftar besar lebih baik menaikkan volume bertahap daripada mengirim
50.000 pesan pada hari pertama.

Throughput pengiriman terpisah dari batas di atas: bawaannya 80 pesan/detik per
nomor dan bisa naik otomatis sampai 1.000 pesan/detik.

---

## 9. Ringkasan pengisian `.env.local`

```env
WA_ACCESS_TOKEN=EAAG...                  # langkah 4 (System User, Never expire)
WA_PHONE_NUMBER_ID=123456789012345       # langkah 2 atau 3
WA_BUSINESS_ACCOUNT_ID=109876543210987   # langkah 2
WA_APP_SECRET=abcdef0123456789...        # langkah 5
WA_WEBHOOK_VERIFY_TOKEN=token-webhook-lazismu-2026   # langkah 6
WA_GRAPH_VERSION=v24.0
WA_GRAPH_BASE_URL=https://graph.facebook.com
```

Setelah semuanya terisi, buka tab **Sistem** di dashboard. Kalau tidak ada lagi
baris "WAJIB DIISI", konfigurasinya sudah lengkap.

---

## Kesalahan yang sering muncul

| Kode | Artinya | Yang perlu dilakukan |
| --- | --- | --- |
| `190` | token kedaluwarsa/dicabut | buat ulang token System User (langkah 4) |
| `132000` | jumlah parameter tidak cocok | pemetaan kolom kurang/lebih dari jumlah variabel template |
| `132001` | template tidak ditemukan | nama atau kode bahasa salah, atau template belum APPROVED |
| `131026` | pesan tak dapat dikirim | nomor tidak terdaftar di WhatsApp |
| `130429` | throughput terlampaui | turunkan `WA_MESSAGES_PER_SECOND` (aplikasi mengulang sendiri) |
| `131056` | batas pasangan nomor | 1 pesan / 6 detik ke nomor yang sama (dijaga otomatis) |
| `131048` | batas laju spam | mutu nomor turun — kampanye ditahan otomatis, tinjau daftar kontak |
| `133010` | nomor belum terdaftar | daftarkan nomor di Cloud API |
| `368` | akun dibatasi sementara | tunggu, dan perbaiki praktik pengiriman |

Daftar lengkap: <https://developers.facebook.com/docs/whatsapp/cloud-api/support/error-codes>
