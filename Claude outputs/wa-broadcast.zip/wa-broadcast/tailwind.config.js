/**
 * Konfigurasi Tailwind untuk dashboard statis.
 * Berkas CSS dibangun sekali dengan `npm run css` lalu disimpan di
 * public/tailwind.css — jadi dashboard tidak bergantung pada CDN dan
 * tetap jalan walau server tanpa akses internet keluar.
 */
module.exports = {
  content: ['./public/**/*.html'],
  theme: { extend: {} },
  plugins: [],
}
