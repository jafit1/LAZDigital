#!/usr/bin/env node
/**
 * tools/mock-graph-server.mjs
 * Tiruan (mock) Meta Graph API untuk pengujian lokal — TIDAK dipakai di produksi.
 *
 * Kegunaannya: menguji seluruh alur (antrean, throttling, retry, webhook status)
 * tanpa mengirim pesan sungguhan dan tanpa membakar biaya per pesan.
 *
 * Jalankan:  npm run mock
 * Lalu di .env.local:  WA_GRAPH_BASE_URL=http://127.0.0.1:4010
 *
 * Perilaku tiruan:
 *   - Nomor berakhiran "999"  -> gagal permanen (kode 131026, nomor tidak ada di WhatsApp)
 *   - Nomor berakhiran "888"  -> gagal setelah terkirim (webhook "failed")
 *   - MOCK_RATE_LIMIT_EVERY=n -> tiap permintaan ke-n dibalas 130429 (uji retry)
 *   - Sisanya                 -> sukses, lalu webhook sent -> delivered -> read
 */

import http from 'node:http'
import crypto from 'node:crypto'
import { muatEnv } from '../lib/muat-env.js'

muatEnv()

const PORT = Number(process.env.MOCK_PORT || 4010)
const WEBHOOK_URL = process.env.MOCK_WEBHOOK_URL || 'http://127.0.0.1:3000/api/webhook'
const APP_SECRET = process.env.WA_APP_SECRET || ''
const RATE_LIMIT_EVERY = Number(process.env.MOCK_RATE_LIMIT_EVERY || 0)
const JEDA_WEBHOOK_MS = Number(process.env.MOCK_WEBHOOK_DELAY_MS || 250)
const PHONE_NUMBER_ID = process.env.WA_PHONE_NUMBER_ID || '1234567890'
const WABA_ID = process.env.WA_BUSINESS_ACCOUNT_ID || '9876543210'

let nomorPermintaan = 0
const statistik = { diterima: 0, sukses: 0, ditolak: 0, webhookTerkirim: 0 }

/* ------------------------------------------------------------------ *
 * Template contoh
 * ------------------------------------------------------------------ */

const TEMPLATE_CONTOH = [
  {
    id: '1000000000000001',
    name: 'kabar_program_lazismu',
    status: 'APPROVED',
    category: 'UTILITY',
    language: 'id',
    components: [
      { type: 'HEADER', format: 'TEXT', text: 'Laporan {{1}}' },
      {
        type: 'BODY',
        text:
          'Assalamualaikum {{1}}, terima kasih atas donasi Anda sebesar Rp{{2}}. ' +
          'Dana tersebut telah disalurkan untuk program {{3}}. Jazakumullah khairan.',
      },
      { type: 'FOOTER', text: 'Balas STOP untuk berhenti menerima pesan' },
      { type: 'BUTTONS', buttons: [{ type: 'URL', text: 'Lihat laporan', url: 'https://contoh.id/laporan/{{1}}' }] },
    ],
  },
  {
    id: '1000000000000002',
    name: 'promo_voucher',
    status: 'APPROVED',
    category: 'MARKETING',
    language: 'id',
    quality_score: { score: 'GREEN' },
    components: [
      { type: 'BODY', text: 'Halo {{1}}! Pakai kode {{2}} untuk potongan belanja di toko kami.' },
    ],
  },
  {
    id: '1000000000000003',
    name: 'pengingat_kegiatan',
    status: 'APPROVED',
    category: 'UTILITY',
    language: 'id',
    components: [
      {
        type: 'BODY',
        text: 'Bapak/Ibu {{nama}}, kegiatan {{acara}} akan dimulai {{waktu}} di {{tempat}}. Mohon kehadirannya.',
      },
    ],
  },
  {
    id: '1000000000000004',
    name: 'template_belum_disetujui',
    status: 'PENDING',
    category: 'MARKETING',
    language: 'id',
    components: [{ type: 'BODY', text: 'Isi apa saja {{1}}' }],
  },
]

/* ------------------------------------------------------------------ *
 * Pengirim webhook tiruan
 * ------------------------------------------------------------------ */

async function kirimWebhook(payload) {
  const body = JSON.stringify(payload)
  const headers = { 'Content-Type': 'application/json' }
  if (APP_SECRET) {
    headers['X-Hub-Signature-256'] =
      'sha256=' + crypto.createHmac('sha256', APP_SECRET).update(body, 'utf8').digest('hex')
  }
  try {
    const res = await fetch(WEBHOOK_URL, { method: 'POST', headers, body })
    statistik.webhookTerkirim++
    if (!res.ok) console.warn(`[mock] webhook dibalas HTTP ${res.status}`)
  } catch (e) {
    console.warn('[mock] gagal mengirim webhook:', e.message)
  }
}

function bungkusStatus(status) {
  return {
    object: 'whatsapp_business_account',
    entry: [
      {
        id: WABA_ID,
        changes: [
          {
            field: 'messages',
            value: {
              messaging_product: 'whatsapp',
              metadata: { display_phone_number: '628000000000', phone_number_id: PHONE_NUMBER_ID },
              statuses: [status],
            },
          },
        ],
      },
    ],
  }
}

function jadwalkanStatus(wamid, tujuan, kategori) {
  const detik = () => Math.floor(Date.now() / 1000)
  const gagalSetelahTerkirim = tujuan.endsWith('888')

  setTimeout(
    () =>
      kirimWebhook(
        bungkusStatus({
          id: wamid,
          status: 'sent',
          timestamp: String(detik()),
          recipient_id: tujuan,
          conversation: { id: `conv_${wamid.slice(-8)}`, origin: { type: kategori?.toLowerCase() || 'utility' } },
          pricing: { billable: true, pricing_model: 'PMP', category: kategori?.toLowerCase() || 'utility' },
        })
      ),
    JEDA_WEBHOOK_MS
  )

  if (gagalSetelahTerkirim) {
    setTimeout(
      () =>
        kirimWebhook(
          bungkusStatus({
            id: wamid,
            status: 'failed',
            timestamp: String(detik()),
            recipient_id: tujuan,
            errors: [
              {
                code: 131026,
                title: 'Message undeliverable',
                error_data: { details: 'Tiruan: perangkat penerima tidak dapat menerima pesan.' },
              },
            ],
          })
        ),
      JEDA_WEBHOOK_MS * 3
    )
    return
  }

  setTimeout(
    () =>
      kirimWebhook(
        bungkusStatus({ id: wamid, status: 'delivered', timestamp: String(detik()), recipient_id: tujuan })
      ),
    JEDA_WEBHOOK_MS * 3
  )

  // Tidak semua pesan dibaca — tiru 70% dibaca.
  if (Math.random() < 0.7) {
    setTimeout(
      () => kirimWebhook(bungkusStatus({ id: wamid, status: 'read', timestamp: String(detik()), recipient_id: tujuan })),
      JEDA_WEBHOOK_MS * 6
    )
  }
}

/* ------------------------------------------------------------------ *
 * Server
 * ------------------------------------------------------------------ */

function balas(res, status, obj) {
  const body = JSON.stringify(obj)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) })
  res.end(body)
}

function galat(res, status, { code, message, subcode, details }) {
  balas(res, status, {
    error: {
      message,
      type: 'OAuthException',
      code,
      error_subcode: subcode,
      error_data: details ? { details } : undefined,
      fbtrace_id: 'MOCK' + Math.random().toString(36).slice(2, 10),
    },
  })
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`)
  const potongan = url.pathname.split('/').filter(Boolean)

  if (url.pathname === '/__statistik') return balas(res, 200, statistik)
  if (url.pathname === '/__sehat') return balas(res, 200, { ok: true })

  const auth = req.headers.authorization || ''
  if (!auth.startsWith('Bearer ') || auth.length < 12) {
    statistik.ditolak++
    return galat(res, 401, { code: 190, message: 'Tiruan: Authorization header tidak sah atau token kosong.' })
  }

  // GET /{versi}/{WABA_ID}/message_templates
  if (req.method === 'GET' && potongan[2] === 'message_templates') {
    return balas(res, 200, { data: TEMPLATE_CONTOH, paging: { cursors: { before: 'A', after: 'B' } } })
  }

  // GET /{versi}/{PHONE_NUMBER_ID}
  if (req.method === 'GET' && potongan.length === 2) {
    return balas(res, 200, {
      id: potongan[1],
      display_phone_number: '+62 800-0000-000',
      verified_name: 'Tiruan Lokal',
      quality_rating: 'GREEN',
      messaging_limit_tier: 'TIER_1K',
      throughput: { level: 'STANDARD' },
    })
  }

  // POST /{versi}/{PHONE_NUMBER_ID}/messages
  if (req.method === 'POST' && potongan[2] === 'messages') {
    const potonganBody = []
    for await (const c of req) potonganBody.push(c)
    let body
    try {
      body = JSON.parse(Buffer.concat(potonganBody).toString('utf8'))
    } catch {
      return galat(res, 400, { code: 100, message: 'Tiruan: badan permintaan bukan JSON.' })
    }

    statistik.diterima++
    nomorPermintaan++

    if (RATE_LIMIT_EVERY > 0 && nomorPermintaan % RATE_LIMIT_EVERY === 0) {
      statistik.ditolak++
      console.log(`[mock] permintaan #${nomorPermintaan}: dibalas 130429 (uji throttling)`)
      return galat(res, 400, {
        code: 130429,
        message: 'Tiruan: Rate limit hit',
        details: 'Message failed to send because there were too many messages sent from this phone number.',
      })
    }

    const tujuan = String(body.to || '')
    if (!tujuan || !body.template?.name) {
      statistik.ditolak++
      return galat(res, 400, { code: 100, message: 'Tiruan: field "to" atau "template.name" kosong.' })
    }

    const tpl = TEMPLATE_CONTOH.find((t) => t.name === body.template.name)
    if (!tpl) {
      statistik.ditolak++
      return galat(res, 400, {
        code: 132001,
        message: 'Tiruan: Template name does not exist in the translation',
        details: `Template ${body.template.name} tidak ditemukan / belum disetujui.`,
      })
    }

    // Periksa jumlah parameter body seperti Meta (kode 132000).
    const bodyKomponen = (body.template.components || []).find((c) => c.type === 'body')
    const diharapkan = (tpl.components.find((c) => c.type === 'BODY')?.text.match(/\{\{[^}]+\}\}/g) || []).length
    const diberi = bodyKomponen?.parameters?.length || 0
    if (diharapkan !== diberi) {
      statistik.ditolak++
      return galat(res, 400, {
        code: 132000,
        message: 'Tiruan: Number of parameters does not match the expected number of params',
        details: `body: number of localizable_params (${diberi}) does not match the expected number of params (${diharapkan}).`,
      })
    }

    if (tujuan.endsWith('999')) {
      statistik.ditolak++
      return galat(res, 400, {
        code: 131026,
        message: 'Tiruan: Message undeliverable',
        details: 'Nomor tidak terdaftar di WhatsApp.',
      })
    }

    const wamid =
      'wamid.MOCK' + Buffer.from(`${tujuan}-${Date.now()}-${nomorPermintaan}`).toString('base64url').slice(0, 26)

    statistik.sukses++
    balas(res, 200, {
      messaging_product: 'whatsapp',
      contacts: [{ input: tujuan, wa_id: tujuan }],
      messages: [{ id: wamid, message_status: 'accepted' }],
    })

    jadwalkanStatus(wamid, tujuan, tpl.category)
    return
  }

  return galat(res, 404, { code: 803, message: `Tiruan: jalur ${url.pathname} tidak dikenal.` })
})

server.listen(PORT, '127.0.0.1', () => {
  console.log('='.repeat(64))
  console.log(' TIRUAN META GRAPH API (hanya untuk pengujian lokal)')
  console.log('='.repeat(64))
  console.log(` Alamat        : http://127.0.0.1:${PORT}`)
  console.log(` Webhook ke    : ${WEBHOOK_URL}`)
  console.log(` Tanda tangan  : ${APP_SECRET ? 'aktif (HMAC SHA-256)' : 'nonaktif (WA_APP_SECRET kosong)'}`)
  console.log(` Uji rate limit: ${RATE_LIMIT_EVERY ? `tiap permintaan ke-${RATE_LIMIT_EVERY}` : 'nonaktif'}`)
  console.log(' Setel di .env.local: WA_GRAPH_BASE_URL=http://127.0.0.1:' + PORT)
  console.log('-'.repeat(64))
})
