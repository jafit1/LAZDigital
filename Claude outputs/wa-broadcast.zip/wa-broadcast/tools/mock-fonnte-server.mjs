#!/usr/bin/env node
/**
 * tools/mock-fonnte-server.mjs
 * Tiruan API Fonnte untuk pengujian lokal — TIDAK dipakai di produksi.
 *
 * Jalankan:  npm run mock:fonnte
 * Lalu di .env.local:  FONNTE_BASE_URL=http://127.0.0.1:4030
 *
 * Perilaku tiruan (dipilih dari nomor tujuan, supaya jalur sulit bisa diuji):
 *   berakhiran 999          -> {status:false, reason:"target invalid"}  (permanen)
 *   berakhiran 888          -> sukses, lalu webhook status "failed"
 *   berakhiran 777          -> {status:false, reason:"insufficient quota"} (tahan)
 *   sisanya                 -> sukses, lalu webhook sent -> delivered -> read
 *
 * Saklar lewat env:
 *   MOCK_FONNTE_DISCONNECT=true   -> /device melaporkan perangkat terputus
 *   MOCK_FONNTE_QUOTA=<angka>     -> sisa kuota yang dilaporkan /device
 *   MOCK_FONNTE_GAGAL_TIAP=<n>    -> tiap permintaan ke-n dibalas galat sementara
 */

import http from 'node:http'
import { muatEnv } from '../lib/muat-env.js'

muatEnv()

const PORT = Number(process.env.MOCK_FONNTE_PORT || 4030)
const WEBHOOK_URL = process.env.MOCK_FONNTE_WEBHOOK_URL || 'http://127.0.0.1:3000/api/webhook/fonnte'
const KUNCI = process.env.FONNTE_WEBHOOK_SECRET || ''
const JEDA_MS = Number(process.env.MOCK_FONNTE_WEBHOOK_DELAY_MS || 200)
const GAGAL_TIAP = Number(process.env.MOCK_FONNTE_GAGAL_TIAP || 0)
const TERPUTUS = String(process.env.MOCK_FONNTE_DISCONNECT || '').toLowerCase() === 'true'
const KUOTA = Number(process.env.MOCK_FONNTE_QUOTA ?? 5000)

let nomorPermintaan = 0
let idBerikut = 80000000
const statistik = { diterima: 0, sukses: 0, ditolak: 0, webhookTerkirim: 0 }

/* ------------------------------------------------------------------ *
 * Pengirim webhook tiruan
 * ------------------------------------------------------------------ */

async function kirimWebhook(payload) {
  const url = KUNCI ? `${WEBHOOK_URL}?kunci=${encodeURIComponent(KUNCI)}` : WEBHOOK_URL
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    statistik.webhookTerkirim++
    if (!res.ok) console.warn(`[mock-fonnte] webhook dibalas HTTP ${res.status}`)
  } catch (e) {
    console.warn('[mock-fonnte] gagal mengirim webhook:', e.message)
  }
}

function jadwalkanStatus(id, target) {
  const device = '628000000000'
  const gagalSetelahTerkirim = target.endsWith('888')

  setTimeout(() => kirimWebhook({ device, id, stateid: 1, status: 'sent', state: 'sent' }), JEDA_MS)

  if (gagalSetelahTerkirim) {
    setTimeout(
      () => kirimWebhook({ device, id, stateid: 9, status: 'failed', state: 'failed' }),
      JEDA_MS * 3
    )
    return
  }

  setTimeout(() => kirimWebhook({ device, id, stateid: 2, status: 'delivered', state: 'delivered' }), JEDA_MS * 3)
  if (Math.random() < 0.7) {
    setTimeout(() => kirimWebhook({ device, id, stateid: 3, status: 'read', state: 'read' }), JEDA_MS * 6)
  }
}

/* ------------------------------------------------------------------ *
 * Server
 * ------------------------------------------------------------------ */

function balas(res, obj, status = 200) {
  const body = JSON.stringify(obj)
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) })
  res.end(body)
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`)

  if (url.pathname === '/__statistik') return balas(res, statistik)
  if (url.pathname === '/__sehat') return balas(res, { ok: true })

  const token = req.headers.authorization || ''
  if (!token || token.length < 8) {
    statistik.ditolak++
    return balas(res, { status: false, reason: 'token invalid', requestid: ++nomorPermintaan })
  }
  /* Fonnte memakai token mentah; kalau ada "Bearer " berarti klien salah. */
  if (/^bearer\s/i.test(token)) {
    statistik.ditolak++
    return balas(res, { status: false, reason: 'token invalid (jangan pakai prefix Bearer)', requestid: ++nomorPermintaan })
  }

  const potongan = []
  for await (const c of req) potongan.push(c)
  let body = {}
  try {
    const teks = Buffer.concat(potongan).toString('utf8')
    body = teks ? JSON.parse(teks) : {}
  } catch {
    return balas(res, { status: false, reason: 'input invalid' })
  }

  /* ---------- POST /device ---------- */
  if (url.pathname === '/device') {
    return balas(res, {
      status: true,
      device: '628000000000',
      name: 'Tiruan Fonnte Lokal',
      device_status: TERPUTUS ? 'disconnect' : 'connect',
      quota: KUOTA,
      messages: statistik.sukses,
      package: 'Master (tiruan)',
      expired: '2027-01-01',
    })
  }

  /* ---------- POST /send ---------- */
  if (url.pathname === '/send') {
    statistik.diterima++
    nomorPermintaan++

    const target = String(body.target || '').trim()
    if (!target) {
      statistik.ditolak++
      return balas(res, { status: false, reason: 'target invalid', requestid: nomorPermintaan })
    }
    if (!String(body.message || '').trim() && !body.url) {
      statistik.ditolak++
      return balas(res, { status: false, reason: 'input invalid', requestid: nomorPermintaan })
    }
    if (TERPUTUS && body.connectOnly !== false) {
      statistik.ditolak++
      return balas(res, { status: false, reason: 'device disconnect', requestid: nomorPermintaan })
    }
    if (GAGAL_TIAP > 0 && nomorPermintaan % GAGAL_TIAP === 0) {
      statistik.ditolak++
      console.log(`[mock-fonnte] permintaan #${nomorPermintaan}: dibalas galat sementara (uji retry)`)
      return balas(res, { status: false, reason: 'too many request, try again later', requestid: nomorPermintaan })
    }
    if (target.endsWith('999')) {
      statistik.ditolak++
      return balas(res, { status: false, reason: 'target invalid', requestid: nomorPermintaan })
    }
    if (target.endsWith('777')) {
      statistik.ditolak++
      return balas(res, { status: false, reason: 'insufficient quota', requestid: nomorPermintaan })
    }

    const id = String(++idBerikut)
    statistik.sukses++

    /* Tiruan mencatat isi pesan yang diterima supaya uji bisa memastikan
       placeholder sudah terisi sebelum keluar dari aplikasi. */
    console.log(`[mock-fonnte] -> ${target}: ${String(body.message || '').slice(0, 80).replace(/\n/g, ' ⏎ ')}`)

    balas(res, {
      status: true,
      detail: 'success! message in queue',
      id: [id],
      target: [target],
      process: 'pending',
      requestid: nomorPermintaan,
    })

    jadwalkanStatus(id, target)
    return
  }

  return balas(res, { status: false, reason: `jalur ${url.pathname} tidak dikenal di tiruan` }, 404)
})

server.listen(PORT, '127.0.0.1', () => {
  console.log('='.repeat(66))
  console.log(' TIRUAN API FONNTE (hanya untuk pengujian lokal)')
  console.log('='.repeat(66))
  console.log(` Alamat        : http://127.0.0.1:${PORT}`)
  console.log(` Webhook ke    : ${WEBHOOK_URL}${KUNCI ? '?kunci=***' : ' (tanpa kunci)'}`)
  console.log(` Perangkat     : ${TERPUTUS ? 'TERPUTUS (uji kegagalan)' : 'tersambung'}`)
  console.log(` Kuota         : ${KUOTA}`)
  console.log(` Galat tiap    : ${GAGAL_TIAP ? `permintaan ke-${GAGAL_TIAP}` : 'nonaktif'}`)
  console.log(' Setel di .env.local: FONNTE_BASE_URL=http://127.0.0.1:' + PORT)
  console.log('-'.repeat(66))
})
