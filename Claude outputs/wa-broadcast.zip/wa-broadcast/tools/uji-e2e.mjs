#!/usr/bin/env node
/**
 * tools/uji-e2e.mjs
 * Uji menyeluruh (end-to-end) tanpa menyentuh Meta sungguhan.
 *
 * Syarat sebelum menjalankan:
 *   1. Terminal A:  npm run mock          (tiruan Graph API di :4010)
 *   2. Terminal B:  npm run dev           (aplikasi di :3000)
 *   3. Terminal C:  npm run uji
 *
 * Yang diperiksa:
 *   - login + penolakan sandi salah + kunci setelah gagal berulang
 *   - handshake webhook (verify token benar & salah)
 *   - penolakan webhook bertanda tangan palsu
 *   - parsing kontak (normalisasi 08xx -> 62xx, buang kembar, tolak yang cacat)
 *   - pembuatan kampanye + antrean
 *   - dispatcher: pengiriman, throttling, retry saat kena 130429
 *   - status masuk lewat webhook: terkirim -> diterima -> dibaca
 *   - nomor uji gagal: 131026 permanen dan gagal setelah terkirim
 *   - aksi tahan / lanjutkan / ulangi-gagal
 *   - unduhan laporan CSV
 */

import crypto from 'node:crypto'
import { muatEnv } from '../lib/muat-env.js'

muatEnv()

const BASIS = process.env.UJI_BASIS || 'http://127.0.0.1:3000'
const MOCK = process.env.UJI_MOCK || 'http://127.0.0.1:4010'
const APP_SECRET = process.env.WA_APP_SECRET || ''
const CRON_SECRET = process.env.CRON_SECRET || ''
const USER = process.env.ADMIN_USERNAME || 'admin'
const SANDI = process.env.UJI_SANDI || 'UjiCoba123'

let cookie = ''
let lulus = 0
let gagal = 0

function ok(nama, keterangan = '') {
  lulus++
  console.log(`  ✓ ${nama}${keterangan ? ' — ' + keterangan : ''}`)
}
function tidakOk(nama, keterangan = '') {
  gagal++
  console.log(`  ✗ ${nama}${keterangan ? ' — ' + keterangan : ''}`)
}
function periksa(syarat, nama, keterangan = '') {
  syarat ? ok(nama, keterangan) : tidakOk(nama, keterangan)
  return !!syarat
}
function judul(t) {
  console.log('\n' + t)
  console.log('-'.repeat(Math.max(t.length, 40)))
}
const tidur = (ms) => new Promise((r) => setTimeout(r, ms))

async function minta(jalur, opsi = {}) {
  const headers = { ...(opsi.headers || {}) }
  if (cookie) headers.Cookie = cookie
  if (opsi.body && typeof opsi.body === 'string' && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json'
  }
  const res = await fetch(BASIS + jalur, { ...opsi, headers, redirect: 'manual' })
  const setCookie = res.headers.get('set-cookie')
  if (setCookie) cookie = setCookie.split(';')[0]
  const teks = await res.text()
  let json = null
  try {
    json = JSON.parse(teks)
  } catch {
    /* balasan bukan JSON (mis. CSV) */
  }
  return { status: res.status, json, teks, headers: res.headers }
}

/* ================================================================== */

async function main() {
  console.log('='.repeat(64))
  console.log(' UJI E2E WA BROADCAST')
  console.log('='.repeat(64))
  console.log(` Aplikasi : ${BASIS}`)
  console.log(` Tiruan   : ${MOCK}`)

  // --- prasyarat -------------------------------------------------
  judul('0. Prasyarat')
  try {
    const r = await fetch(MOCK + '/__sehat')
    periksa(r.ok, 'tiruan Graph API hidup')
  } catch {
    tidakOk('tiruan Graph API hidup', 'jalankan "npm run mock" dulu')
    return selesai()
  }
  const sehat = await minta('/api/health')
  if (!periksa(sehat.status === 200, 'aplikasi hidup', `driver=${sehat.json?.penyimpanan?.driver}`)) {
    console.log('    jalankan "npm run dev" dulu')
    return selesai()
  }
  periksa(
    sehat.json?.graph?.basis?.includes('127.0.0.1'),
    'WA_GRAPH_BASE_URL menunjuk ke tiruan',
    sehat.json?.graph?.basis
  )

  // --- login -----------------------------------------------------
  judul('1. Autentikasi')
  const salah = await minta('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username: USER, sandi: 'sandi-yang-salah' }),
  })
  periksa(salah.status === 401, 'sandi salah ditolak', `HTTP ${salah.status}`)
  periksa(
    !/sandi salah untuk/i.test(salah.json?.pesan || '') && salah.json?.pesan === 'Username atau sandi salah.',
    'pesan galat seragam (tidak membocorkan username)'
  )

  const masuk = await minta('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username: USER, sandi: SANDI }),
  })
  if (!periksa(masuk.status === 200, 'login berhasil', masuk.json?.pesan || '')) return selesai()
  periksa(!!cookie && cookie.startsWith('wab_sesi='), 'cookie sesi HttpOnly diterima')

  const aku = await minta('/api/auth/me')
  periksa(aku.json?.masuk === true, 'sesi terbaca di /api/auth/me')
  periksa(
    JSON.stringify(aku.json).includes('EAAG') === false,
    'balasan /api/auth/me tidak membocorkan access token'
  )

  const tanpaCookie = await fetch(BASIS + '/api/campaigns')
  periksa(tanpaCookie.status === 401, 'endpoint kampanye menolak permintaan tanpa sesi')

  // --- webhook ---------------------------------------------------
  judul('2. Webhook')
  const hsBenar = await fetch(
    `${BASIS}/api/webhook?hub.mode=subscribe&hub.verify_token=${encodeURIComponent(
      process.env.WA_WEBHOOK_VERIFY_TOKEN || ''
    )}&hub.challenge=tantangan123`
  )
  const isiHs = await hsBenar.text()
  periksa(hsBenar.status === 200 && isiHs === 'tantangan123', 'handshake dengan verify token benar dibalas challenge')

  const hsSalah = await fetch(
    `${BASIS}/api/webhook?hub.mode=subscribe&hub.verify_token=token-ngawur&hub.challenge=x`
  )
  periksa(hsSalah.status === 403, 'handshake dengan verify token salah ditolak 403')

  const badanPalsu = JSON.stringify({ object: 'whatsapp_business_account', entry: [] })
  const palsu = await fetch(BASIS + '/api/webhook', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': 'sha256=' + '0'.repeat(64) },
    body: badanPalsu,
  })
  periksa(palsu.status === 401, 'webhook bertanda tangan palsu ditolak 401', `HTTP ${palsu.status}`)

  const tandaSah =
    'sha256=' + crypto.createHmac('sha256', APP_SECRET).update(badanPalsu, 'utf8').digest('hex')
  const sah = await fetch(BASIS + '/api/webhook', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': tandaSah },
    body: badanPalsu,
  })
  periksa(sah.status === 200, 'webhook bertanda tangan sah diterima 200')

  // --- template --------------------------------------------------
  judul('3. Template dari WABA')
  const tpl = await minta('/api/templates?segar=1')
  const daftar = tpl.json?.template || []
  periksa(tpl.status === 200 && daftar.length > 0, 'daftar template tertarik', `${daftar.length} template`)
  periksa(
    daftar.every((t) => t.status === 'APPROVED'),
    'hanya template APPROVED yang muncul (yang PENDING disaring)'
  )
  const tBerurut = daftar.find((t) => t.nama === 'promo_voucher')
  const tBernama = daftar.find((t) => t.nama === 'pengingat_kegiatan')
  periksa(tBerurut?.jumlahVariabel === 2 && !tBerurut?.bernama, 'variabel berurut terdeteksi ({{1}}, {{2}})')
  periksa(
    tBernama?.bernama === true && tBernama.variabel.includes('nama'),
    'variabel bernama terdeteksi ({{nama}}, {{acara}}, …)'
  )

  // --- parsing kontak -------------------------------------------
  judul('4. Parsing kontak')
  const teksKontak = [
    'telepon;nama;kode',
    '081200000001;Ahmad Maruf;VC-01',
    '0812-0000-0002;Siti Aminah;VC-02',
    '+62 812 0000 0003;Budi Santoso;VC-03',
    '6281200000004;Dewi Lestari;VC-04',
    '081200000001;Ahmad Duplikat;VC-99',
    'bukan-nomor;Salah Isi;VC-98',
    '081200000888;Uji Gagal Kirim;VC-88',
    '081200000999;Uji Nomor Mati;VC-77',
  ].join('\n')

  const kontak = await minta('/api/contacts/parse', { method: 'POST', body: JSON.stringify({ teks: teksKontak }) })
  const kj = kontak.json
  periksa(kontak.status === 200, 'parsing tempelan teks berhasil')
  periksa(kj?.jumlahSah === 6, 'jumlah nomor sah = 6', `dapat ${kj?.jumlahSah}`)
  periksa(kj?.jumlahDitolak === 2, 'baris kembar & cacat ditolak = 2', `dapat ${kj?.jumlahDitolak}`)
  periksa(kj?.baris?.[0]?.telepon === '6281200000001', 'nomor 08xx dinormalkan ke 62xx', kj?.baris?.[0]?.telepon)
  periksa(kj?.baris?.[1]?.telepon === '6281200000002', 'tanda hubung dibuang', kj?.baris?.[1]?.telepon)
  periksa(kj?.baris?.[2]?.telepon === '6281200000003', 'format +62 dengan spasi dibaca', kj?.baris?.[2]?.telepon)
  periksa(
    JSON.stringify(kj?.headerParameter) === JSON.stringify(['nama', 'kode']),
    'kolom parameter terbaca dari header',
    JSON.stringify(kj?.headerParameter)
  )

  // --- salah pemetaan ditolak -----------------------------------
  judul('5. Penjagaan jumlah parameter')
  const salahPeta = await minta('/api/campaigns', {
    method: 'POST',
    body: JSON.stringify({
      nama: 'Uji pemetaan salah',
      template: { nama: tBerurut.nama, bahasa: tBerurut.bahasa, variabel: tBerurut.variabel, bernama: false },
      pemetaan: [0], // template butuh 2
      baris: kj.baris,
    }),
  })
  periksa(salahPeta.status === 400, 'pemetaan kurang parameter ditolak sebelum menyentuh Meta', salahPeta.json?.pesan)

  // --- buat kampanye --------------------------------------------
  judul('6. Kampanye + pengiriman')
  const buat = await minta('/api/campaigns', {
    method: 'POST',
    body: JSON.stringify({
      nama: 'Uji E2E ' + new Date().toISOString().slice(11, 19),
      template: {
        nama: tBerurut.nama,
        bahasa: tBerurut.bahasa,
        kategori: tBerurut.kategori,
        bernama: false,
        variabel: tBerurut.variabel,
        teksBody: tBerurut.teksBody,
      },
      pemetaan: [0, 1],
      baris: kj.baris,
      langsungJalan: true,
    }),
  })
  const kid = buat.json?.kampanye?.id
  if (!periksa(buat.status === 200 && !!kid, 'kampanye dibuat', kid)) return selesai()
  periksa(buat.json.jumlahAntre === 6, 'semua penerima masuk antrean', `${buat.json.jumlahAntre}`)

  // Jalankan dispatcher lewat jalur cron (memakai CRON_SECRET, seperti Vercel).
  // Percobaan ulang setelah 130429 memakai backoff 30 detik lebih, jadi
  // batas waktunya dibuat longgar.
  let putaran = 0
  let statAkhir = null
  const tenggat = Date.now() + 120_000
  while (putaran < 40 && Date.now() < tenggat) {
    putaran++
    const d = await fetch(`${BASIS}/api/cron/dispatch?detik=8`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${CRON_SECRET}` },
    })
    const dj = await d.json()
    if (putaran === 1) {
      periksa(d.status === 200 && dj.pemicu === 'cron', 'dispatcher dipicu dengan CRON_SECRET')
    }
    const s = await minta(`/api/campaigns/${kid}`)
    statAkhir = s.json?.stat
    if (statAkhir && statAkhir.antre === 0) break
    await tidur(600)
  }

  periksa(statAkhir?.antre === 0, 'antrean kampanye habis', `sisa antre ${statAkhir?.antre}`)
  periksa(statAkhir?.gagal >= 1, 'nomor berakhiran 999 gagal permanen (kode 131026)', `gagal=${statAkhir?.gagal}`)

  const cronTanpaToken = await fetch(`${BASIS}/api/cron/dispatch`, { method: 'POST' })
  periksa(cronTanpaToken.status === 401, 'dispatcher menolak pemicu tanpa CRON_SECRET / sesi')

  // --- webhook status masuk -------------------------------------
  judul('7. Status dari webhook')
  let stat = statAkhir
  for (let i = 0; i < 15; i++) {
    await tidur(500)
    const s = await minta(`/api/campaigns/${kid}`)
    stat = s.json?.stat
    if ((stat.diterima || 0) + (stat.dibaca || 0) >= 3) break
  }
  periksa((stat.diterima || 0) + (stat.dibaca || 0) >= 3, 'status "delivered/read" masuk lewat webhook',
    `terkirim=${stat.terkirim} diterima=${stat.diterima} dibaca=${stat.dibaca}`)

  const penerima = await minta(`/api/campaigns/${kid}/recipients?limit=100`)
  const baris = penerima.json?.baris || []
  const b888 = baris.find((b) => b.telepon.endsWith('888'))
  const b999 = baris.find((b) => b.telepon.endsWith('999'))
  periksa(!!b999 && b999.status === 'gagal' && b999.kodeGalat === 131026,
    'nomor 999: gagal saat kirim dengan kode 131026', `${b999?.status} / ${b999?.kodeGalat}`)
  periksa(!!b888 && b888.status === 'gagal',
    'nomor 888: gagal lewat webhook setelah sempat terkirim', `${b888?.status} / kode ${b888?.kodeGalat}`)
  const terkirimSukses = baris.filter((b) => ['terkirim', 'diterima', 'dibaca'].includes(b.status))
  periksa(
    terkirimSukses.length > 0 && terkirimSukses.every((b) => !!b.wamid),
    'setiap pesan sukses menyimpan wamid',
    `${terkirimSukses.length} pesan sukses`
  )
  periksa(baris.some((b) => b.coba > 1), 'ada pekerjaan yang diulang setelah kena 130429 (retry bekerja)',
    `coba maksimal = ${Math.max(...baris.map((b) => b.coba || 0))}`)
  periksa(baris.some((b) => b.harga?.kategori), 'kategori harga dari webhook tersimpan',
    baris.find((b) => b.harga?.kategori)?.harga?.kategori)

  // --- aksi kampanye --------------------------------------------
  judul('8. Aksi kampanye')
  const tahan = await minta(`/api/campaigns/${kid}/actions`, { method: 'POST', body: JSON.stringify({ aksi: 'tahan' }) })
  periksa(tahan.json?.kampanye?.status === 'ditahan' || tahan.json?.kampanye?.status === 'selesai',
    'aksi tahan diterima', tahan.json?.kampanye?.status)

  const ulangi = await minta(`/api/campaigns/${kid}/actions`, { method: 'POST', body: JSON.stringify({ aksi: 'ulangi-gagal' }) })
  periksa(ulangi.json?.hasil?.diulang >= 1, 'aksi ulangi-gagal memasukkan kembali yang gagal',
    `${ulangi.json?.hasil?.diulang} baris`)

  const batal = await minta(`/api/campaigns/${kid}/actions`, { method: 'POST', body: JSON.stringify({ aksi: 'batalkan' }) })
  periksa(batal.json?.kampanye?.status === 'dibatalkan', 'aksi batalkan menyetel status dibatalkan')

  const aksiNgawur = await minta(`/api/campaigns/${kid}/actions`, { method: 'POST', body: JSON.stringify({ aksi: 'terbang' }) })
  periksa(aksiNgawur.status === 400, 'aksi tidak dikenal ditolak')

  // --- opt-out ---------------------------------------------------
  judul('9. Daftar tolak kirim')
  await minta('/api/optout', { method: 'POST', body: JSON.stringify({ nomor: ['081200000002'] }) })
  const daftarTolak = await minta('/api/optout')
  periksa(daftarTolak.json?.nomor?.includes('6281200000002'), 'nomor masuk daftar tolak kirim (ternormalkan)')

  const kampanye2 = await minta('/api/campaigns', {
    method: 'POST',
    body: JSON.stringify({
      nama: 'Uji opt-out',
      template: { nama: tBerurut.nama, bahasa: tBerurut.bahasa, bernama: false, variabel: tBerurut.variabel },
      pemetaan: [0, 1],
      baris: kj.baris,
      langsungJalan: false,
    }),
  })
  periksa(kampanye2.json?.jumlahDilewati === 1, 'nomor opt-out otomatis dilewati saat kampanye dibuat',
    `dilewati=${kampanye2.json?.jumlahDilewati}`)
  periksa(kampanye2.json?.kampanye?.status === 'ditahan', 'langsungJalan=false membuat kampanye ditahan')
  await minta('/api/optout', { method: 'DELETE', body: JSON.stringify({ nomor: ['081200000002'] }) })

  // --- laporan CSV ----------------------------------------------
  judul('10. Laporan CSV')
  const csv = await minta(`/api/campaigns/${kid}/recipients?format=csv`)
  const barisCsv = csv.teks.trim().split('\n')
  periksa(csv.headers.get('content-type')?.includes('text/csv'), 'balasan bertipe text/csv')
  periksa(barisCsv[0].includes('telepon;status;wamid'), 'kepala kolom CSV benar')
  periksa(barisCsv.length === 7, 'CSV memuat 6 baris data + kepala', `${barisCsv.length} baris`)

  // --- kunci login berulang -------------------------------------
  judul('11. Kunci setelah gagal berulang')
  // IP palsu supaya penguncian tidak mengunci alamat asli — kalau tidak,
  // menjalankan uji ini dua kali berturut-turut akan tertolak sendiri.
  const ipUji = `203.0.113.${Math.floor(Math.random() * 200) + 10}`
  const cookieSimpan = cookie
  cookie = ''
  let kena429 = false
  for (let i = 0; i < 7; i++) {
    const r = await minta('/api/auth/login', {
      method: 'POST',
      headers: { 'X-Forwarded-For': ipUji },
      body: JSON.stringify({ username: 'akun-lain-' + i, sandi: 'salah-terus' }),
    })
    if (r.status === 429) { kena429 = true; break }
  }
  periksa(kena429, 'login dikunci setelah 5 kali gagal dari IP yang sama', ipUji)
  cookie = cookieSimpan

  return selesai()
}

function selesai() {
  console.log('\n' + '='.repeat(64))
  console.log(` HASIL: ${lulus} lulus, ${gagal} gagal`)
  console.log('='.repeat(64))
  process.exit(gagal > 0 ? 1 : 0)
}

main().catch((e) => {
  console.error('\nUji berhenti karena kesalahan:', e)
  process.exit(1)
})
