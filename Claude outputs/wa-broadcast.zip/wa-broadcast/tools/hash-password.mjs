#!/usr/bin/env node
/**
 * tools/hash-password.mjs
 * Membuat nilai ADMIN_PASSWORD_HASH untuk .env.local.
 *
 * Pakai:  npm run sandi -- "SandiRahasia123"
 */

import { hashSandi } from '../lib/auth.js'

const sandi = process.argv[2]

if (!sandi) {
  console.error('Pakai: npm run sandi -- "SandiRahasia123"')
  console.error('Syarat: minimal 8 karakter, memuat huruf dan angka.')
  process.exit(1)
}

try {
  const hash = hashSandi(sandi)
  console.log('\nSalin baris ini ke .env.local:\n')
  console.log(`ADMIN_PASSWORD_HASH=${hash}\n`)
} catch (e) {
  console.error('Gagal:', e.message)
  process.exit(1)
}
