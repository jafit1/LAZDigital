#!/usr/bin/env node
/**
 * tools/mock-upstash-server.mjs
 * Tiruan Upstash Redis REST API — HANYA untuk menguji driver produksi
 * (lib/store/upstash.js) tanpa perlu akun Upstash.
 *
 * Jalankan:  node tools/mock-upstash-server.mjs
 * Lalu di .env.local:
 *   STORE_DRIVER=upstash
 *   UPSTASH_REDIS_REST_URL=http://127.0.0.1:4020
 *   UPSTASH_REDIS_REST_TOKEN=token-uji
 *
 * Perintah yang didukung hanyalah yang dipakai aplikasi ini.
 * JANGAN dipakai sebagai Redis sungguhan.
 */

import http from 'node:http'

const PORT = Number(process.env.MOCK_UPSTASH_PORT || 4020)

/** @type {Map<string, {t:string, v:any, exp:number|null}>} */
const db = new Map()

function hidup(key) {
  const rec = db.get(key)
  if (!rec) return null
  if (rec.exp !== null && rec.exp <= Date.now()) {
    db.delete(key)
    return null
  }
  return rec
}

function ambil(key, tipe, kosong) {
  const rec = hidup(key)
  if (rec) {
    if (rec.t !== tipe) throw new Error('WRONGTYPE Operation against a key holding the wrong kind of value')
    return rec
  }
  const baru = { t: tipe, v: kosong, exp: null }
  db.set(key, baru)
  return baru
}

function potongIndeks(panjang, start, stop) {
  let a = Number(start)
  let b = Number(stop)
  if (a < 0) a = Math.max(panjang + a, 0)
  if (b < 0) b = panjang + b
  b = Math.min(b, panjang - 1)
  return [a, b]
}

function jalankan(argv) {
  const cmd = String(argv[0] || '').toUpperCase()
  const a = argv.slice(1).map(String)

  switch (cmd) {
    case 'PING':
      return 'PONG'

    case 'GET': {
      const rec = hidup(a[0])
      return rec && rec.t === 's' ? rec.v : null
    }

    case 'SET': {
      const key = a[0]
      const nilai = a[1]
      const opsi = a.slice(2).map((x) => x.toUpperCase())
      const ada = hidup(key)
      if (opsi.includes('NX') && ada) return null
      if (opsi.includes('XX') && !ada) return null
      let exp = null
      const iEX = opsi.indexOf('EX')
      if (iEX >= 0) exp = Date.now() + Number(a.slice(2)[iEX + 1]) * 1000
      if (opsi.includes('KEEPTTL')) exp = ada?.exp ?? null
      db.set(key, { t: 's', v: nilai, exp })
      return 'OK'
    }

    case 'DEL': {
      let n = 0
      for (const key of a) if (db.delete(key)) n++
      return n
    }

    case 'MGET':
      return a.map((key) => {
        const rec = hidup(key)
        return rec && rec.t === 's' ? rec.v : null
      })

    case 'INCRBY': {
      const rec = hidup(a[0])
      const nilai = (rec && rec.t === 's' ? Number(rec.v) : 0) + Number(a[1])
      db.set(a[0], { t: 's', v: String(nilai), exp: rec?.exp ?? null })
      return nilai
    }

    case 'EXPIRE': {
      const rec = hidup(a[0])
      if (!rec) return 0
      rec.exp = Date.now() + Number(a[1]) * 1000
      return 1
    }

    case 'HSET': {
      const rec = ambil(a[0], 'h', {})
      let n = 0
      for (let i = 1; i < a.length; i += 2) {
        if (rec.v[a[i]] === undefined) n++
        rec.v[a[i]] = a[i + 1]
      }
      return n
    }

    case 'HGETALL': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'h') return []
      return Object.entries(rec.v).flat()
    }

    case 'HINCRBY': {
      const rec = ambil(a[0], 'h', {})
      const nilai = Number(rec.v[a[1]] || 0) + Number(a[2])
      rec.v[a[1]] = String(nilai)
      return nilai
    }

    case 'RPUSH': {
      const rec = ambil(a[0], 'l', [])
      rec.v.push(...a.slice(1))
      return rec.v.length
    }

    case 'LPUSH': {
      const rec = ambil(a[0], 'l', [])
      rec.v.unshift(...a.slice(1))
      return rec.v.length
    }

    case 'LPOP': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'l' || rec.v.length === 0) return null
      const jumlah = a[1] !== undefined ? Number(a[1]) : null
      if (jumlah === null) return rec.v.shift()
      return rec.v.splice(0, jumlah)
    }

    case 'LRANGE': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'l') return []
      const [i, j] = potongIndeks(rec.v.length, a[1], a[2])
      return j < i ? [] : rec.v.slice(i, j + 1)
    }

    case 'LLEN': {
      const rec = hidup(a[0])
      return rec && rec.t === 'l' ? rec.v.length : 0
    }

    case 'LTRIM': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'l') return 'OK'
      const [i, j] = potongIndeks(rec.v.length, a[1], a[2])
      rec.v = j < i ? [] : rec.v.slice(i, j + 1)
      return 'OK'
    }

    case 'ZADD': {
      const rec = ambil(a[0], 'z', [])
      let n = 0
      for (let i = 1; i < a.length; i += 2) {
        const score = Number(a[i])
        const member = a[i + 1]
        const idx = rec.v.findIndex((x) => x.member === member)
        if (idx >= 0) rec.v[idx].score = score
        else {
          rec.v.push({ member, score })
          n++
        }
      }
      rec.v.sort((x, y) => x.score - y.score || x.member.localeCompare(y.member))
      return n
    }

    case 'ZRANGEBYSCORE': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'z') return []
      const min = a[1] === '-inf' ? -Infinity : Number(a[1])
      const max = a[2] === '+inf' ? Infinity : Number(a[2])
      let hasil = rec.v.filter((x) => x.score >= min && x.score <= max).map((x) => x.member)
      const iLimit = a.findIndex((x) => x.toUpperCase() === 'LIMIT')
      if (iLimit >= 0) hasil = hasil.slice(Number(a[iLimit + 1]), Number(a[iLimit + 1]) + Number(a[iLimit + 2]))
      return hasil
    }

    case 'ZRANGE': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'z') return []
      const rev = a.some((x) => x.toUpperCase() === 'REV')
      const arr = rev ? [...rec.v].reverse() : rec.v
      const [i, j] = potongIndeks(arr.length, a[1], a[2])
      return j < i ? [] : arr.slice(i, j + 1).map((x) => x.member)
    }

    case 'ZREM': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 'z') return 0
      const buang = new Set(a.slice(1))
      const sebelum = rec.v.length
      rec.v = rec.v.filter((x) => !buang.has(x.member))
      return sebelum - rec.v.length
    }

    case 'ZCARD': {
      const rec = hidup(a[0])
      return rec && rec.t === 'z' ? rec.v.length : 0
    }

    case 'SADD': {
      const rec = ambil(a[0], 't', new Set())
      let n = 0
      for (const m of a.slice(1)) if (!rec.v.has(m)) { rec.v.add(m); n++ }
      return n
    }

    case 'SREM': {
      const rec = hidup(a[0])
      if (!rec || rec.t !== 't') return 0
      let n = 0
      for (const m of a.slice(1)) if (rec.v.delete(m)) n++
      return n
    }

    case 'SISMEMBER': {
      const rec = hidup(a[0])
      return rec && rec.t === 't' && rec.v.has(a[1]) ? 1 : 0
    }

    case 'SMEMBERS': {
      const rec = hidup(a[0])
      return rec && rec.t === 't' ? [...rec.v] : []
    }

    default:
      throw new Error(`ERR unknown command '${cmd}'`)
  }
}

const server = http.createServer(async (req, res) => {
  const auth = req.headers.authorization || ''
  if (!auth.startsWith('Bearer ')) {
    res.writeHead(401, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ error: 'Unauthorized' }))
  }

  const potongan = []
  for await (const c of req) potongan.push(c)
  let badan
  try {
    badan = JSON.parse(Buffer.concat(potongan).toString('utf8') || 'null')
  } catch {
    res.writeHead(400, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ error: 'invalid JSON' }))
  }

  const kirim = (obj) => {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify(obj))
  }

  try {
    if (req.url.startsWith('/pipeline')) {
      return kirim(
        badan.map((perintah) => {
          try {
            return { result: jalankan(perintah) }
          } catch (e) {
            return { error: e.message }
          }
        })
      )
    }
    return kirim({ result: jalankan(badan) })
  } catch (e) {
    res.writeHead(400, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ error: e.message }))
  }
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`[tiruan-upstash] siap di http://127.0.0.1:${PORT} — hanya untuk pengujian`)
})
