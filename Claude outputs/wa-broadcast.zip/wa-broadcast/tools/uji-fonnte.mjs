#!/usr/bin/env node
/**
 * tools/uji-fonnte.mjs
 * Uji menyeluruh jalur Fonnte, tanpa menyentuh Fonnte sungguhan.
 *
 * Syarat:
 *   Terminal A:  npm run mock      (tiruan API Fonnte di :4030)
 *   Terminal B:  npm run dev       (aplikasi di :3000, PENGIRIM=fonnte)
 *   Terminal C:  npm run uji
 *
 * Yang diperiksa:
 *   - pengirim aktif = fonnte, dan daftar template kosong dengan keterangan
 *   - keadaan perangkat & kuota terbaca
 *   - pustaka pesan: simpan, ambil, hapus, tolak placeholder tanpa kolom
 *   - placeholder terisi sebelum keluar aplikasi (bukan diserahkan ke Fonnte)
 *   - jeda acak antar pesan benar-benar menahan pengiriman
 *   - nomor 999 gagal permanen, 777 menahan kampanye (kuota habis)
 *   - webhook Fonnte: kunci salah ditolak, status sent/delivered/read masuk
 *   - balasan "STOP" masuk daftar tolak kirim
 */

import { muatEnv } from '../lib/muat-env.js'

muatEnv()

const BASIS = process.env.UJI_BASIS || 'http://127.0.0.1:3000'
const MOCK = process.env.FONNTE_BASE_URL || 'http://127.0.0.1:4030'
const KUNCI = process.env.FONNTE_WEBHOOK_SECRET || ''
const CRON_SECRET = process.env.CRON_SECRET || ''
const USER = process.env.ADMIN_USERNAME || 'admin'
const SANDI = process.env.UJI_SANDI || 'UjiCoba123'

let cookie = ''
let lulus = 0
let gagal = 0

const ok = (n, k = '') => { lulus++; console.log(`  ✓ ${n}${k ? ' — ' + k : ''}`) }
const tidakOk = (n, k = '') => { gagal++; console.log(`  ✗ ${n}${k ? ' — ' + k : ''}`) }
const periksa = (s, n, k = '') => { s ? ok(n, k) : tidakOk(n, k); return !!s }
const judul = (t) => { console.log('\n' + t); console.log('-'.repeat(Math.max(t.length, 42))) }
const tidur = (ms) => new Promise((r) => setTimeout(r, ms))

async function minta(jalur, opsi = {}) {
  const headers = { ...(opsi.headers || {}) }
  if (cookie) headers.Cookie = cookie
  if (opsi.body && typeof opsi.body === 'string' && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json'
  }
  const res = await fetch(BASIS + jalur, { ...opsi, headers, redirect: 'manual' })
  const sc = res.headers.get('set-cookie')
  if (sc) cookie = sc.split(';')[0]
  const teks = await res.text()
  let json = null
  try { json = JSON.parse(teks) } catch {}
  return { status: res.status, json, teks, headers: res.headers }
}

async function main() {
  console.log('='.repeat(66))
  console.log(' UJI JALUR FONNTE')
  console.log('='.repeat(66))
  console.log(` Aplikasi : ${BASIS}`)
  console.log(` Tiruan   : ${MOCK}`)

  /* ---------- 0. prasyarat ---------- */
  judul('0. Prasyarat')
  try {
    const r = await fetch(MOCK + '/__sehat')
    periksa(r.ok, 'tiruan Fonnte hidup')
  } catch {
    tidakOk('tiruan Fonnte hidup', 'jalankan "npm run mock" dulu')
    return selesai()
  }
  const sehat = await minta('/api/health')
  if (!periksa(sehat.status === 200, 'aplikasi hidup', `pengirim=${sehat.json?.pengirim}`)) return selesai()
  if (!periksa(sehat.json?.pengirim === 'fonnte', 'PENGIRIM=fonnte aktif', String(sehat.json?.pengirim))) return selesai()
  periksa(sehat.json?.fonnte?.basis?.includes('127.0.0.1'), 'FONNTE_BASE_URL menunjuk ke tiruan', sehat.json?.fonnte?.basis)

  /* ---------- 1. login ---------- */
  judul('1. Masuk')
  const masuk = await minta('/api/auth/login', { method: 'POST', body: JSON.stringify({ username: USER, sandi: SANDI }) })
  if (!periksa(masuk.status === 200, 'login berhasil', masuk.json?.pesan || '')) return selesai()
  const aku = await minta('/api/auth/me')
  periksa(aku.json?.setelan?.pengirim === 'fonnte', 'dashboard tahu pengirimnya Fonnte')
  periksa(aku.json?.setelan?.pakaiPesanBebas === true, 'mode pesan bebas menyala')
  periksa(aku.json?.setelan?.jalurWebhook === '/api/webhook/fonnte', 'jalur webhook yang dianjurkan benar')
  periksa(!JSON.stringify(aku.json).includes(process.env.FONNTE_TOKEN || 'TOKENTAKMUNGKIN'),
    'token Fonnte tidak bocor ke balasan API')

  /* ---------- 2. perangkat & kuota ---------- */
  judul('2. Keadaan perangkat')
  const perangkat = await minta('/api/perangkat')
  periksa(perangkat.status === 200, 'info perangkat terbaca')
  periksa(perangkat.json?.info?.tersambung === true, 'perangkat dilaporkan tersambung')
  periksa(typeof perangkat.json?.info?.kuota === 'number', 'sisa kuota terbaca', String(perangkat.json?.info?.kuota))
  periksa(perangkat.json?.info?.jenis === 'fonnte', 'jenis pengirim benar')

  /* ---------- 3. template kosong ---------- */
  judul('3. Template (harus kosong di mode Fonnte)')
  const tpl = await minta('/api/templates')
  periksa(tpl.json?.pakaiPesanBebas === true && (tpl.json?.template || []).length === 0,
    'daftar template kosong dengan keterangan, bukan galat', tpl.json?.keterangan)

  /* ---------- 4. pustaka pesan ---------- */
  judul('4. Pustaka pesan')
  const isiPesan =
    'Assalamualaikum {nama}, terima kasih donasi Anda Rp{nominal} untuk program {program}. ' +
    'Jazakumullah khairan.\n\nBalas STOP untuk berhenti menerima pesan.'

  const cekYatim = await minta('/api/pesan?aksi=periksa', {
    method: 'POST',
    body: JSON.stringify({ teks: 'Halo {nama}, kode {kode_rahasia}', kolom: ['nama', 'nominal'] }),
  })
  periksa(cekYatim.json?.sah === false, 'placeholder tanpa pasangan kolom ditolak',
    (cekYatim.json?.galat || []).join(' '))

  const simpan = await minta('/api/pesan', {
    method: 'POST',
    body: JSON.stringify({
      nama: 'Laporan penyaluran donasi',
      teks: isiPesan,
      kolom: ['nama', 'nominal', 'program'],
    }),
  })
  const pesanId = simpan.json?.pesan?.id
  periksa(simpan.status === 200 && !!pesanId, 'pesan tersimpan ke pustaka', pesanId)
  periksa(
    JSON.stringify(simpan.json?.placeholder) === JSON.stringify(['nama', 'nominal', 'program']),
    'placeholder terdeteksi urut', JSON.stringify(simpan.json?.placeholder)
  )

  const daftar = await minta('/api/pesan')
  periksa((daftar.json?.pesan || []).some((p) => p.id === pesanId), 'pesan muncul di daftar pustaka')

  /* ---------- 5. kontak ---------- */
  judul('5. Kontak')
  const teksKontak = [
    'telepon;nama;nominal;program',
    "081200000101;Ahmad Ma'ruf;150.000;Beasiswa Yatim",
    '081200000102;Siti Aminah;250.000;Bantuan Kesehatan',
    '081200000888;Uji Gagal Webhook;100.000;Uji',
    '081200000999;Uji Nomor Mati;100.000;Uji',
  ].join('\n')
  const kontak = await minta('/api/contacts/parse', { method: 'POST', body: JSON.stringify({ teks: teksKontak }) })
  const kj = kontak.json
  periksa(kj?.jumlahSah === 4, 'empat nomor terbaca', String(kj?.jumlahSah))
  periksa(kj?.baris?.[0]?.telepon === '6281200000101', 'nomor dinormalkan ke 62xx', kj?.baris?.[0]?.telepon)

  /* ---------- 6. kampanye mode pesan ---------- */
  judul('6. Kampanye pesan bebas')
  const baris = kj.baris.map((b) => ({
    telepon: b.telepon,
    kolom: { nama: b.params[0], nominal: b.params[1], program: b.params[2] },
  }))

  const buat = await minta('/api/campaigns', {
    method: 'POST',
    body: JSON.stringify({
      nama: 'Uji Fonnte ' + new Date().toISOString().slice(11, 19),
      pesan: { pesanId },
      kolom: ['nama', 'nominal', 'program'],
      baris,
      langsungJalan: true,
    }),
  })
  const kid = buat.json?.kampanye?.id
  if (!periksa(buat.status === 200 && !!kid, 'kampanye dibuat', kid)) return selesai()
  periksa(buat.json?.kampanye?.mode === 'pesan', 'kampanye bermode "pesan"')
  periksa(buat.json?.kampanye?.pengirim === 'fonnte', 'pengirim tercatat di kampanye')

  const contoh = buat.json?.contohPesan?.[0]?.teks || ''
  periksa(contoh.includes("Ahmad Ma'ruf") && contoh.includes('150.000') && contoh.includes('Beasiswa Yatim'),
    'pratinjau pesan sudah terisi placeholder')
  periksa(!contoh.includes('{'), 'tidak ada placeholder yang tertinggal di pratinjau')

  /* ---------- 7. jeda antar pesan ---------- */
  judul('7. Jeda acak antar pesan')
  const jedaMin = Number(process.env.WA_JEDA_MIN_DETIK ?? 10)
  const t0 = Date.now()
  const putaran1 = await fetch(`${BASIS}/api/cron/dispatch?detik=3`, {
    method: 'POST', headers: { Authorization: `Bearer ${CRON_SECRET}` },
  })
  const p1 = await putaran1.json()
  const terkirim1 = p1.hitungan?.terkirim || 0
  const maksWajar = Math.max(1, Math.ceil(3 / jedaMin) + 1)
  periksa(terkirim1 <= maksWajar,
    `putaran 3 detik hanya mengirim ${terkirim1} pesan (jeda ${jedaMin}s menahan sisanya)`,
    `batas wajar ${maksWajar}`)
  periksa(p1.hitungan?.ditunda >= 1, 'sisa pekerjaan ditunda, bukan dipaksa keluar', `ditunda=${p1.hitungan?.ditunda}`)

  /* ---------- 8. kuras antrean ---------- */
  judul('8. Pengiriman sampai antrean habis')
  let stat = null
  const tenggat = Date.now() + 120_000
  while (Date.now() < tenggat) {
    await fetch(`${BASIS}/api/cron/dispatch?detik=8`, {
      method: 'POST', headers: { Authorization: `Bearer ${CRON_SECRET}` },
    }).catch(() => {})
    const s = await minta(`/api/campaigns/${kid}`)
    stat = s.json?.stat
    const kp = s.json?.kampanye
    if (stat && stat.antre === 0) break
    if (kp && kp.status === 'ditahan') break
    await tidur(1200)
  }
  periksa(stat?.antre === 0, 'antrean kampanye habis', `sisa antre ${stat?.antre}`)
  console.log(`    (lama total ${Math.round((Date.now() - t0) / 1000)} detik untuk 4 pesan)`)

  const penerima = await minta(`/api/campaigns/${kid}/recipients?limit=50`)
  const rows = penerima.json?.baris || []
  const r999 = rows.find((r) => r.telepon.endsWith('999'))
  periksa(!!r999 && r999.status === 'gagal', 'nomor 999 gagal permanen ("target invalid")',
    `${r999?.status} · ${r999?.pesanGalat}`)
  periksa(rows.filter((r) => r.wamid).every((r) => String(r.wamid).startsWith('fonnte:')),
    'id pesan Fonnte tersimpan sebagai penanda balik')

  /* ---------- 9. webhook ---------- */
  judul('9. Webhook Fonnte')
  const tanpaKunci = await fetch(`${BASIS}/api/webhook/fonnte`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ device: '628', id: '1', status: 'sent' }),
  })
  periksa(tanpaKunci.status === 401, 'webhook tanpa ?kunci= ditolak 401', `HTTP ${tanpaKunci.status}`)

  const kunciSalah = await fetch(`${BASIS}/api/webhook/fonnte?kunci=ngawur`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ device: '628', id: '1', status: 'sent' }),
  })
  periksa(kunciSalah.status === 401, 'webhook dengan kunci salah ditolak 401')

  let statW = stat
  for (let i = 0; i < 14; i++) {
    await tidur(500)
    const s = await minta(`/api/campaigns/${kid}`)
    statW = s.json?.stat
    if ((statW.diterima || 0) + (statW.dibaca || 0) >= 1) break
  }
  periksa((statW.diterima || 0) + (statW.dibaca || 0) >= 1,
    'status delivered/read masuk lewat webhook',
    `terkirim=${statW.terkirim} diterima=${statW.diterima} dibaca=${statW.dibaca}`)

  const rows2 = (await minta(`/api/campaigns/${kid}/recipients?limit=50`)).json?.baris || []
  const r888 = rows2.find((r) => r.telepon.endsWith('888'))
  periksa(!!r888 && r888.status === 'gagal', 'nomor 888 gagal lewat webhook setelah terkirim',
    `${r888?.status} · ${r888?.pesanGalat}`)

  /* status tak dikenal tidak boleh mengubah apa pun */
  const takDikenal = await fetch(`${BASIS}/api/webhook/fonnte?kunci=${encodeURIComponent(KUNCI)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ device: '628', id: '99999999', status: 'entahapa', state: 'entahapa' }),
  })
  const tdJson = await takDikenal.json()
  periksa(takDikenal.status === 200 && (tdJson.ringkasan?.statusTakDikenal || []).length === 1,
    'status yang tidak dikenal dicatat, bukan diterjemahkan sembarangan')

  /* ---------- 10. balasan STOP ---------- */
  judul('10. Balasan STOP')
  await fetch(`${BASIS}/api/webhook/fonnte?kunci=${encodeURIComponent(KUNCI)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ device: '628000000000', sender: '081200000101', message: 'STOP', name: 'Ahmad' }),
  })
  const optout = await minta('/api/optout')
  periksa((optout.json?.nomor || []).includes('6281200000101'),
    'pembalas STOP masuk daftar tolak kirim')

  const kampanye2 = await minta('/api/campaigns', {
    method: 'POST',
    body: JSON.stringify({
      nama: 'Uji opt-out Fonnte',
      pesan: { teks: 'Halo {nama}, ini uji. Balas STOP untuk berhenti.' },
      kolom: ['nama'],
      baris: [{ telepon: '6281200000101', kolom: { nama: 'Ahmad' } }],
      langsungJalan: false,
    }),
  })
  periksa(kampanye2.json?.jumlahDilewati === 1, 'nomor opt-out dilewati saat kampanye dibuat')
  await minta('/api/optout', { method: 'DELETE', body: JSON.stringify({ nomor: ['6281200000101'] }) })

  /* ---------- 11. laporan & bersih-bersih ---------- */
  judul('11. Laporan CSV & bersih-bersih')
  const csv = await minta(`/api/campaigns/${kid}/recipients?format=csv`)
  periksa(csv.headers.get('content-type')?.includes('text/csv') && csv.teks.includes('telepon;status;wamid'),
    'laporan CSV terunduh dengan kepala kolom benar')

  const hapus = await minta(`/api/pesan/${pesanId}`, { method: 'DELETE' })
  periksa(hapus.status === 200, 'pesan bisa dihapus dari pustaka')

  return selesai()
}

function selesai() {
  console.log('\n' + '='.repeat(66))
  console.log(` HASIL: ${lulus} lulus, ${gagal} gagal`)
  console.log('='.repeat(66))
  process.exit(gagal > 0 ? 1 : 0)
}

main().catch((e) => {
  console.error('\nUji berhenti karena kesalahan:', e)
  process.exit(1)
})
